const CACHE_NAME = 'speedbeam-shell-v1';

const SHELL_FILES = [
  './',
  './index.html',
  './manifest.json',
  './css/variables.css',
  './css/base.css',
  './css/layout.css',
  './css/components.css',
  './css/animations.css',
  './css/responsive.css',
  './js/main.js',
  './js/scene/index.js',
  './js/scene/background.js',
  './js/scene/sphere.js',
  './js/speedtest/engine.js',
  './js/speedtest/sequence.js',
  './js/ui/speedometer.js',
  './js/ui/results.js',
  './js/ui/assistant.js',
  './js/ui/history.js',
  './js/ui/graph.js',
  './js/ui/share.js',
  './js/ui/planCompare.js',
  './js/ui/geoinfo.js',
  './js/ui/monitor.js',
  './js/audio/sound.js',
  './assets/favicon-32.png',
  './assets/apple-touch-icon.png',
  './assets/logo-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).catch(() => {
      // if precaching fails (e.g. offline-first install), the app still
      // works online — this is a progressive enhancement, not required
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Never intercept the actual speed-test traffic, the Claude assistant
  // API, or any cross-origin request — only cache same-origin app-shell
  // files. Getting this wrong would silently break real measurements.
  if (url.origin !== self.location.origin || url.pathname.startsWith('/api/')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).catch(() => cached);
    })
  );
});
