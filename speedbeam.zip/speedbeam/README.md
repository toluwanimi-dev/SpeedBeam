# SpeedBeam

A cinematic, holographic internet speed test. Built with vanilla HTML/CSS/JS
(ES modules), Three.js, and GSAP — no build step, no framework, no bundler.

## Run locally

Because this uses ES modules, open it through a local server rather than
double-clicking the file (the `file://` protocol blocks module imports).

```bash
# any static server works, e.g.:
npx serve .
# or
python3 -m http.server 8080
```

Then visit the printed local URL.

## Deploy

This is a static site — drop the folder as-is into any of these:

- **Vercel**: `vercel deploy` from this folder, or drag-and-drop in the
  dashboard. No build command needed; set the output directory to `.`
- **Netlify**: drag-and-drop this folder in the Netlify dashboard, or
  `netlify deploy`. Publish directory: `.`
- **GitHub Pages**: push this folder to a repo and enable Pages on the
  branch/root.

## AI-generated assistant verdict (optional)

By default, the "Beam Assistant" message is written by simple rules in
`js/ui/assistant.js` — no API key needed, works out of the box.

If you want that message to instead be generated live by Claude:

1. In your Vercel project dashboard, go to **Settings → Environment
   Variables**.
2. Add a variable named `ANTHROPIC_API_KEY` with your Anthropic Console
   API key as the value. Never put this key in any frontend file —
   `api/assistant.js` is a serverless function that runs only on
   Vercel's servers, keeping it secret.
3. Redeploy. The frontend will automatically call `/api/assistant`
   after each test and swap in the AI-written verdict once it arrives;
   if the call fails for any reason (no key set, rate limit, network
   issue), it silently keeps the instant rule-based message instead —
   the UI never breaks or shows an error to the user over this.

This only works when deployed to Vercel (or any host that runs the
`api/` folder as serverless functions). Running via a plain static
server (`npx serve .`) will just keep the rule-based message, since
there's no server to run `api/assistant.js`.

## What's new (v3) — Dashboard gauge + ISP detection

- **Redesigned speedometer**: a proper automotive-dashboard gauge — a 270° arc, tick marks that rescale to the connection speed, and a needle that smoothly accelerates/decelerates toward the live measured value instead of snapping (`js/ui/speedometer.js`). A DOWNLOAD/UPLOAD/LATENCY badge above the readout makes it unambiguous which metric is live.
- **More accurate engine**: download/upload measurements now discard an initial warm-up window (~400-600ms) from the final Mbps calculation, so TCP slow-start doesn't drag down an otherwise-fast connection (`js/speedtest/engine.js`). Ping now uses the median of 8 rounds rather than a plain mean, so one slow round doesn't skew it.
- **ISP/provider detection**: `js/ui/geoinfo.js` matches the IP-based org string against known carriers (MTN, Airtel, Glo, 9mobile, Starlink, and several global ISPs) for a clean name, infers a connection type (Mobile/Broadband/Satellite/Unknown), and falls back to "Network provider unavailable" rather than guessing. Detection runs during a "Detecting Network" stage that's race'd against a 1.2s timeout so it never meaningfully delays the test.
- **Ping quality badge**: Excellent/Very Good/Good/Fair/High label next to the latency metric.
- **Results panel** now shows Network, Connection type, and Test Server alongside the existing metrics.

## What's new (v2)

Beyond the original cinematic speed test, this build adds:

- **Live throughput graph** — a glowing trail of instantaneous Mbps during download/upload, next to the speedometer.
- **Shareable result card** — "Share result" renders a branded PNG (canvas-generated, no server round-trip) and downloads it.
- **Plan comparison** — enter your ISP's advertised speed in Settings; results show what % of it you're actually getting.
- **Packet loss estimate** — approximated from ping rounds that never got a response (browsers can't measure true ICMP packet loss).
- **History trend chart** — a sparkline of your last 20 download speeds in the History panel.
- **CSV/JSON export** — download your full test history from the History panel.
- **Dynamic grade coloring** — the grade card's color shifts green/cyan for A grades through amber/red for D-F.
- **Multi-connection mode** — toggle in Settings between single-stream (realistic for calls/gaming) and 4-parallel-stream (closer to advertised ISP numbers) testing.
- **Monitor mode** — optional automatic re-test every 5 minutes, feeding the same history/trend chart, for diagnosing an intermittent connection.
- **Stage-completion particle bursts** and an **idle easter egg** (linger 30s and the sphere gives a small pulse).
- **"How this works" panel** — explains in Settings that results are real measurements, not simulated.
- **PWA support** — installable, with an offline-capable app shell (`manifest.json` + `sw.js`); the speed test itself still needs a real connection, obviously.
- **Open Graph / Twitter Card image** — shared links now show a branded preview instead of a blank card.

Left out on purpose, since they need infrastructure beyond a static site:
- **Global leaderboard** — would need a real database (e.g. Vercel KV/Postgres) to store and rank anonymous results across users.
- **True multi-server region selection** — there's only one practical free CORS-enabled endpoint (Cloudflare's); offering a real region picker would need your own set of test servers.

## How the speed test works

`js/speedtest/engine.js` performs real measurements:

- **Ping/jitter**: several round-trip `fetch` calls, averaged
- **Download**: streamed `fetch` reads, sampling live throughput as bytes
  arrive
- **Upload**: streamed `POST` of randomly generated payloads, sampling
  throughput as chunks complete

By default it targets Cloudflare's public speed-test endpoints
(`speed.cloudflare.com/__down` / `__up`), which are CORS-enabled and need no
API key. If a deployment environment blocks that host (corporate proxy,
strict CSP, etc.), swap the URLs in `ENDPOINTS` at the top of `engine.js` for
any host that serves a large file and accepts a CORS POST.

## Structure

```
index.html
css/
  variables.css      design tokens (palette, type, motion)
  base.css            resets, background gradients
  layout.css          structural layout
  components.css      buttons, cards, HUD rings
  animations.css       keyframes, reduced-motion overrides
  responsive.css       breakpoints
js/
  main.js              wires everything together
  scene/
    index.js           renderer, camera drift + parallax, render loop
    background.js       starfield, nebula, grid floor, network nodes
    sphere.js            the hero holographic sphere (signature element)
  speedtest/
    engine.js            real ping/download/upload measurement
    sequence.js          orchestrates the 5 cinematic stages
  ui/
    speedometer.js       HUD ring + live numeric readout
    results.js           results card reveal
    assistant.js         AI verdict copy from real results
    history.js           localStorage history, search, delete, clear
  audio/
    sound.js             synthesized UI sounds (Web Audio, no files)
```

## Accessibility & performance notes

- Respects `prefers-reduced-motion`: camera drift, particle motion, and
  entrance animations are disabled/shortened.
- Live regions announce test stage changes and final results for screen
  readers.
- Rendering pauses when the tab is hidden.
- Pixel ratio is capped (1.6–2x) to keep frame rate steady on mobile GPUs.
