/**
 * Vercel serverless function. Runs on the server, not in the browser,
 * so the ANTHROPIC_API_KEY environment variable (set in the Vercel
 * project dashboard, never in client code) stays secret.
 *
 * The frontend POSTs the test results here; this asks Claude to write
 * a short, natural verdict; the response goes straight back to the UI.
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: 'ANTHROPIC_API_KEY is not configured on this deployment.' });
    return;
  }

  const { download, upload, ping, jitter, grade } = req.body || {};
  if (
    typeof download !== 'number' ||
    typeof upload !== 'number' ||
    typeof ping !== 'number' ||
    typeof jitter !== 'number' ||
    typeof grade !== 'string'
  ) {
    res.status(400).json({ error: 'Missing or invalid result fields.' });
    return;
  }

  const prompt = `You are the "Beam Assistant" inside a sleek internet speed-test app called SpeedBeam. A user just completed a speed test with these real measured results:

Download: ${download.toFixed(1)} Mbps
Upload: ${upload.toFixed(1)} Mbps
Ping: ${Math.round(ping)} ms
Jitter: ${jitter.toFixed(1)} ms
Network Grade: ${grade}

Write a short verdict (2-4 sentences, no headers, no markdown, no bullet points) explaining what this connection is good for day to day — streaming quality, video calls, gaming, uploads — in plain, friendly language. Do not just restate the numbers back. Vary your phrasing naturally.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      res.status(502).json({ error: `Claude API error: ${errText}` });
      return;
    }

    const data = await response.json();
    const text = (data.content || [])
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join(' ')
      .trim();

    if (!text) {
      res.status(502).json({ error: 'Claude API returned no text.' });
      return;
    }

    res.status(200).json({ text });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Unknown error calling Claude API.' });
  }
}
