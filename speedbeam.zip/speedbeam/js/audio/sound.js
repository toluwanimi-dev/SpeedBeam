/**
 * Very subtle futuristic sound layer, entirely synthesized via
 * WebAudio (no audio files to fetch). Muted by default rules aside,
 * the toggle in the topbar controls whether these ever play.
 */
export class SoundEngine {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.master = null;
  }

  _ensureContext() {
    if (this.ctx) return;
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    this.ctx = new AudioCtx();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.18;
    this.master.connect(this.ctx.destination);
  }

  setEnabled(v) {
    this.enabled = v;
  }

  _tone({ freq = 440, duration = 0.18, type = 'sine', gain = 1, sweepTo = null }) {
    if (!this.enabled) return;
    this._ensureContext();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    if (sweepTo) {
      osc.frequency.linearRampToValueAtTime(sweepTo, this.ctx.currentTime + duration);
    }
    g.gain.setValueAtTime(0, this.ctx.currentTime);
    g.gain.linearRampToValueAtTime(gain, this.ctx.currentTime + 0.015);
    g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

    osc.connect(g);
    g.connect(this.master);
    osc.start();
    osc.stop(this.ctx.currentTime + duration + 0.02);
  }

  click() {
    this._tone({ freq: 880, duration: 0.09, type: 'sine', gain: 0.5 });
  }

  hover() {
    this._tone({ freq: 1200, duration: 0.05, type: 'sine', gain: 0.18 });
  }

  charge() {
    this._tone({ freq: 220, sweepTo: 660, duration: 0.7, type: 'triangle', gain: 0.35 });
  }

  stageTransition() {
    this._tone({ freq: 520, sweepTo: 780, duration: 0.25, type: 'sine', gain: 0.28 });
  }

  complete() {
    if (!this.enabled) return;
    this._tone({ freq: 660, duration: 0.2, type: 'sine', gain: 0.4 });
    setTimeout(() => this._tone({ freq: 880, duration: 0.3, type: 'sine', gain: 0.4 }), 120);
  }
}
