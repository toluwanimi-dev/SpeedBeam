const STORAGE_KEY = 'speedbeam.plan.v1';

export function loadPlanSpeed() {
  const v = localStorage.getItem(STORAGE_KEY);
  return v ? Number(v) : null;
}

export function savePlanSpeed(mbps) {
  try {
    if (mbps > 0) localStorage.setItem(STORAGE_KEY, String(mbps));
    else localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore storage failures
  }
}

/** Returns a short human-readable comparison string, or null if no plan is set. */
export function comparePlan(measuredDownload, planMbps) {
  if (!planMbps || planMbps <= 0) return null;
  const pct = Math.round((measuredDownload / planMbps) * 100);
  if (pct >= 95) return `You're getting ${pct}% of your ${planMbps} Mbps plan — right on target.`;
  if (pct >= 75) return `You're getting ${pct}% of your ${planMbps} Mbps plan — a bit under, but normal.`;
  if (pct >= 50) return `You're only getting ${pct}% of your ${planMbps} Mbps plan — worth investigating.`;
  return `You're getting just ${pct}% of your ${planMbps} Mbps plan — well below what you're paying for.`;
}
