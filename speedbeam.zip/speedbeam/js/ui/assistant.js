/**
 * Generates the "AI Network Assistant" verdict from the actual
 * measured results. Copy is written from the end user's side: what
 * they can expect to do on this connection, not raw stats restated.
 */
export function buildAssistantMessage({ download, upload, ping, jitter, grade }) {
  const lines = [];

  if (grade === 'A+' || grade === 'A') {
    lines.push('Excellent connection detected.');
  } else if (grade === 'B') {
    lines.push('Solid, dependable connection.');
  } else if (grade === 'C') {
    lines.push('Usable connection with some limits.');
  } else if (grade === 'D') {
    lines.push('Weak connection — expect some slowdowns.');
  } else {
    lines.push('This connection is struggling right now.');
  }

  if (download >= 80) {
    lines.push('4K streaming and large downloads will feel instant.');
  } else if (download >= 25) {
    lines.push('HD streaming and everyday browsing will run smoothly.');
  } else if (download >= 8) {
    lines.push('Standard-definition streaming should hold up, but 4K may buffer.');
  } else {
    lines.push('Streaming and big downloads will likely feel sluggish.');
  }

  if (ping <= 30 && jitter <= 8) {
    lines.push('Cloud gaming and video calls should stay responsive.');
  } else if (ping <= 70) {
    lines.push('Video calls should stay stable, though fast-paced gaming may lag.');
  } else {
    lines.push('Expect noticeable lag in real-time video calls or gaming.');
  }

  if (upload >= 15) {
    lines.push('Large file uploads and screen sharing will complete quickly.');
  } else if (upload >= 5) {
    lines.push('Uploads will move at a reasonable pace.');
  } else {
    lines.push('Uploading large files may take a while.');
  }

  return lines.join(' ');
}

/**
 * Asks the /api/assistant serverless function (which calls Claude
 * server-side) to write a natural-language verdict for these results.
 * Returns null on any failure so the caller can silently keep the
 * rule-based message instead — this should never break the UI.
 */
export async function fetchAiAssistantMessage(result) {
  try {
    const response = await fetch('/api/assistant', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        download: result.download,
        upload: result.upload,
        ping: result.ping,
        jitter: result.jitter,
        grade: result.grade
      })
    });
    if (!response.ok) return null;
    const data = await response.json();
    return typeof data.text === 'string' && data.text.trim() ? data.text.trim() : null;
  } catch {
    return null;
  }
}
