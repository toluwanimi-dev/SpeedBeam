/**
 * Minimal canvas line-chart, used two ways in SpeedBeam:
 *  - a live scrolling trail of instantaneous Mbps during a test
 *  - a small trend sparkline of the last N historical download speeds
 * No chart library needed for something this simple.
 */
export class LiveGraph {
  constructor(canvas, { maxPoints = 80, color = '#00d4ff', fillColor = 'rgba(0,212,255,0.12)' } = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.maxPoints = maxPoints;
    this.color = color;
    this.fillColor = fillColor;
    this.values = [];
    this._resize();
    window.addEventListener('resize', () => this._resize());
  }

  _resize() {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.max(1, rect.width * dpr);
    this.canvas.height = Math.max(1, rect.height * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.width = rect.width;
    this.height = rect.height;
  }

  reset() {
    this.values = [];
    this._draw();
  }

  push(value) {
    this.values.push(value);
    if (this.values.length > this.maxPoints) this.values.shift();
    this._draw();
  }

  setSeries(values) {
    this.values = values.slice(-this.maxPoints);
    this._draw();
  }

  _draw() {
    const { ctx, width, height, values } = this;
    ctx.clearRect(0, 0, width, height);
    if (values.length < 2) return;

    const max = Math.max(...values, 1) * 1.15;
    const stepX = width / (this.maxPoints - 1);
    const offsetX = width - (values.length - 1) * stepX;

    const points = values.map((v, i) => {
      const x = offsetX + i * stepX;
      const y = height - (v / max) * height;
      return [x, y];
    });

    // filled area under the line
    ctx.beginPath();
    ctx.moveTo(points[0][0], height);
    points.forEach(([x, y]) => ctx.lineTo(x, y));
    ctx.lineTo(points[points.length - 1][0], height);
    ctx.closePath();
    ctx.fillStyle = this.fillColor;
    ctx.fill();

    // line
    ctx.beginPath();
    points.forEach(([x, y], i) => (i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y)));
    ctx.strokeStyle = this.color;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.stroke();

    // glowing dot at the current point
    const [lx, ly] = points[points.length - 1];
    ctx.beginPath();
    ctx.arc(lx, ly, 3.5, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 10;
    ctx.fill();
    ctx.shadowBlur = 0;
  }
}
