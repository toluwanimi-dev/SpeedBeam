/**
 * A futuristic automotive-dashboard-style gauge: a 270° arc, tick
 * marks with numeric labels, and a needle that smoothly accelerates
 * and decelerates toward the live measured value (rather than
 * snapping). The same dial is reused for download Mbps, upload Mbps,
 * and ping ms — only the adaptive max scale and color differ.
 *
 * Angle convention: 135° = value 0 (bottom-left), 405°(=45°) = value
 * max (bottom-right), sweeping 270° clockwise through the top — the
 * classic car-speedometer gap at the bottom.
 */
const CX = 180;
const CY = 190;
const R = 150;
const START_DEG = 135;
const SWEEP_DEG = 270;

const STAGE_LABELS = {
  idle: 'Ready',
  prepare: 'Connecting',
  detect: 'Detecting network',
  scan: 'Connecting',
  ping: 'Measuring latency',
  download: 'Download',
  upload: 'Upload',
  resolve: 'Finalizing'
};

// "Nice" scale ceilings the gauge rescales through. Includes a slow-
// connection tier (10) and goes up to 10,000 Mbps; beyond that,
// pickScale() computes a fresh ceiling dynamically so the needle can
// never get permanently stuck at a hardcoded maximum.
const MBPS_SCALES = [10, 25, 50, 100, 200, 300, 500, 750, 1000, 1500, 2000, 3000, 5000, 7500, 10000];
const MS_SCALES = [50, 100, 200, 400, 800];

/** Rounds up to a clean-looking ceiling for scales beyond our tiers. */
function dynamicCeiling(value) {
  const magnitude = 10 ** Math.floor(Math.log10(Math.max(value, 1)));
  return Math.ceil((value * 1.2) / magnitude) * magnitude;
}

function pickScale(value, table) {
  for (const s of table) {
    if (value <= s * 0.85) return s;
  }
  // Value exceeds every predefined tier (an extremely fast connection) —
  // extend dynamically rather than pinning the needle at the old max.
  return dynamicCeiling(value);
}

function polar(cx, cy, r, angleDeg) {
  const a = (angleDeg * Math.PI) / 180;
  return [cx + r * Math.cos(a), cy + r * Math.sin(a)];
}

function arcPath(cx, cy, r, startDeg, endDeg) {
  const [x1, y1] = polar(cx, cy, r, startDeg);
  const [x2, y2] = polar(cx, cy, r, endDeg);
  const largeArc = endDeg - startDeg > 180 ? 1 : 0;
  return `M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${r} ${r} 0 ${largeArc} 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`;
}

export class Speedometer {
  constructor() {
    this.dialTrack = document.getElementById('dial-track');
    this.dialFill = document.getElementById('dial-fill');
    this.tickGroup = document.getElementById('tick-group');
    this.tickLabelGroup = document.getElementById('tick-label-group');
    this.needle = document.getElementById('needle');
    this.valueEl = document.getElementById('hud-value');
    this.unitEl = document.getElementById('hud-unit');
    this.stageEl = document.getElementById('hud-stage');
    this.modeEl = document.getElementById('hud-mode');

    this.dialTrack.setAttribute('d', arcPath(CX, CY, R, START_DEG, START_DEG + SWEEP_DEG));

    this.currentUnit = 'Mbps';
    this.scale = MBPS_SCALES[3]; // 200 default starting ceiling
    this.displayed = 0; // smoothed value the needle actually shows
    this.target = 0; // latest raw measurement
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    this._rafId = null;

    this._drawTicks();
    this.reset();
    this._loop();
  }

  _drawTicks(count = 10) {
    this.tickGroup.innerHTML = '';
    this.tickLabelGroup.innerHTML = '';
    for (let i = 0; i <= count; i++) {
      const t = i / count;
      const deg = START_DEG + t * SWEEP_DEG;
      const major = i % 2 === 0;
      const [x1, y1] = polar(CX, CY, R + 8, deg);
      const [x2, y2] = polar(CX, CY, R + (major ? 22 : 16), deg);
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', x1.toFixed(1));
      line.setAttribute('y1', y1.toFixed(1));
      line.setAttribute('x2', x2.toFixed(1));
      line.setAttribute('y2', y2.toFixed(1));
      line.setAttribute('class', major ? 'tick major' : 'tick');
      this.tickGroup.appendChild(line);

      if (major) {
        const [lx, ly] = polar(CX, CY, R + 38, deg);
        const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('x', lx.toFixed(1));
        label.setAttribute('y', ly.toFixed(1));
        label.setAttribute('class', 'tick-label');
        label.dataset.t = t;
        this.tickLabelGroup.appendChild(label);
      }
    }
    this._updateTickLabels();
  }

  _updateTickLabels() {
    const labels = this.tickLabelGroup.querySelectorAll('.tick-label');
    labels.forEach((label) => {
      const t = Number(label.dataset.t);
      const v = t * this.scale;
      label.textContent = v >= 1000 ? `${(v / 1000).toFixed(1)}k` : Math.round(v).toString();
    });
  }

  _valueToDeg(value) {
    const t = Math.max(0, Math.min(value / this.scale, 1));
    return START_DEG + t * SWEEP_DEG;
  }

  reset() {
    this.target = 0;
    this.displayed = 0;
    this.scale = this.currentUnit === 'ms' ? MS_SCALES[0] : MBPS_SCALES[3];
    this._updateTickLabels();
    this.valueEl.textContent = '0.0';
    this.stageEl.textContent = 'Ready';
    this.modeEl.textContent = 'IDLE';
    this.modeEl.removeAttribute('data-mode');
    this._render(0);
  }

  setStage(stage) {
    this.stageEl.textContent = STAGE_LABELS[stage] ?? stage;
    const modeMap = { download: 'DOWNLOAD', upload: 'UPLOAD', ping: 'LATENCY' };
    const mode = modeMap[stage];
    if (mode) {
      this.modeEl.textContent = mode;
      this.modeEl.setAttribute('data-mode', stage === 'upload' ? 'upload' : 'download');
    } else {
      this.modeEl.textContent = STAGE_LABELS[stage]?.toUpperCase() ?? 'WORKING';
      this.modeEl.removeAttribute('data-mode');
    }
  }

  /** value: number, unit: 'Mbps' | 'ms'. Sets the target the needle animates toward. */
  setLive(value, unit) {
    const unitChanged = unit !== this.currentUnit;
    this.currentUnit = unit;
    this.unitEl.textContent = unit;
    const table = unit === 'ms' ? MS_SCALES : MBPS_SCALES;

    if (unitChanged) {
      // Fresh baseline for the new metric — without this, a leftover
      // ms-scale (e.g. 800) could be larger than a fresh Mbps reading
      // needs, and since the scale only ever grows within a run, the
      // needle would barely move for a long time after switching
      // from latency to download/upload.
      this.scale = pickScale(value, table);
      this._updateTickLabels();
      this.displayed = value; // snap once on the mode switch, not ease from the old metric's leftover value
    } else {
      const neededScale = pickScale(value, table);
      if (neededScale > this.scale) {
        this.scale = neededScale;
        this._updateTickLabels();
      }
    }
    this.target = value;
  }

  showFinal({ download }) {
    this.setLive(download, 'Mbps');
    this.stageEl.textContent = 'Test complete';
    this.modeEl.textContent = 'DOWNLOAD';
    this.modeEl.setAttribute('data-mode', 'download');
  }

  /** Smoothly eases the needle/readout toward the target every frame —
   * this is what gives "acceleration and deceleration" instead of snaps. */
  _loop() {
    const ease = this.reducedMotion ? 1 : 0.13;
    this.displayed += (this.target - this.displayed) * ease;
    if (Math.abs(this.displayed - this.target) < 0.05) this.displayed = this.target;
    this._render(this.displayed);
    this._rafId = requestAnimationFrame(() => this._loop());
  }

  _render(value) {
    const deg = this._valueToDeg(value);
    this.dialFill.setAttribute('d', arcPath(CX, CY, R, START_DEG, deg));

    const [nx, ny] = polar(CX, CY, R - 26, deg);
    const [bx1, by1] = polar(CX, CY, 9, deg + 90);
    const [bx2, by2] = polar(CX, CY, 9, deg - 90);
    this.needle.setAttribute('points', `${nx.toFixed(1)},${ny.toFixed(1)} ${bx1.toFixed(1)},${by1.toFixed(1)} ${bx2.toFixed(1)},${by2.toFixed(1)}`);

    this.valueEl.textContent = value < 10 ? value.toFixed(1) : Math.round(value).toString();
  }

  dispose() {
    if (this._rafId) cancelAnimationFrame(this._rafId);
  }
}
