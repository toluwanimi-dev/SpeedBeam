const CIRCUMFERENCE = 2 * Math.PI * 140; // matches r=140 in the SVG

const STAGE_LABELS = {
  idle: 'Ready',
  scan: 'Scanning',
  ping: 'Measuring ping',
  download: 'Download',
  upload: 'Upload',
  resolve: 'Analyzing'
};

/**
 * Maps a raw value (Mbps or ms) to a 0..1 ring fill using a soft
 * square-root scale so both slow and very fast connections read
 * legibly on the same gauge, rather than a hard linear cap.
 */
function toRingFraction(value, max) {
  const clamped = Math.max(0, Math.min(value, max));
  return Math.sqrt(clamped / max);
}

export class Speedometer {
  constructor() {
    this.ring = document.getElementById('ring-progress');
    this.valueEl = document.getElementById('hud-value');
    this.unitEl = document.getElementById('hud-unit');
    this.stageEl = document.getElementById('hud-stage');
    this.tickGroup = document.getElementById('tick-group');
    this.ring.style.strokeDasharray = `${CIRCUMFERENCE}`;
    this._buildTicks();
    this.reset();
  }

  _buildTicks() {
    const count = 40;
    const cx = 180, cy = 180, rOuter = 152, rInner = 146;
    const frag = document.createDocumentFragment();
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2 - Math.PI / 2;
      const x1 = cx + rInner * Math.cos(angle);
      const y1 = cy + rInner * Math.sin(angle);
      const x2 = cx + rOuter * Math.cos(angle);
      const y2 = cy + rOuter * Math.sin(angle);
      const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', x1.toFixed(1));
      line.setAttribute('y1', y1.toFixed(1));
      line.setAttribute('x2', x2.toFixed(1));
      line.setAttribute('y2', y2.toFixed(1));
      line.setAttribute('stroke', 'rgba(232,244,255,0.16)');
      line.setAttribute('stroke-width', '1.4');
      frag.appendChild(line);
    }
    this.tickGroup.appendChild(frag);
  }

  reset() {
    this.ring.style.strokeDashoffset = `${CIRCUMFERENCE}`;
    this.valueEl.textContent = '0.0';
    this.unitEl.textContent = 'Mbps';
    this.stageEl.textContent = 'Ready';
  }

  setStage(stage) {
    this.stageEl.textContent = STAGE_LABELS[stage] ?? stage;
  }

  /** value: number, unit: 'Mbps' | 'ms' */
  setLive(value, unit) {
    const max = unit === 'ms' ? 200 : 500;
    const frac = toRingFraction(value, max);
    this.ring.style.strokeDashoffset = `${CIRCUMFERENCE * (1 - frac)}`;
    this.valueEl.textContent = value < 10 ? value.toFixed(1) : Math.round(value).toString();
    this.unitEl.textContent = unit;
  }

  showFinal({ download }) {
    this.setLive(download, 'Mbps');
    this.stageEl.textContent = 'Complete';
  }
}
