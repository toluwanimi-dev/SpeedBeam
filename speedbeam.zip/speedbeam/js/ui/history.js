const STORAGE_KEY = 'speedbeam.history.v1';
const MAX_ENTRIES = 50;

function loadEntries() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveEntries(entries) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch {
    // storage unavailable (private browsing, quota) — fail silently
  }
}

function formatDate(ts) {
  const d = new Date(ts);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) +
    ' · ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
}

export class HistoryPanel {
  constructor() {
    this.panel = document.getElementById('history-panel');
    this.scrim = document.getElementById('scrim');
    this.toggleBtn = document.getElementById('history-toggle');
    this.closeBtn = document.getElementById('history-close');
    this.list = document.getElementById('history-list');
    this.empty = document.getElementById('history-empty');
    this.searchInput = document.getElementById('history-search');
    this.clearBtn = document.getElementById('history-clear');
    this.exportJsonBtn = document.getElementById('history-export-json');
    this.exportCsvBtn = document.getElementById('history-export-csv');
    this.trendGraph = null;

    this.entries = loadEntries();

    this.toggleBtn.addEventListener('click', () => this.open());
    this.closeBtn.addEventListener('click', () => this.close());
    this.scrim.addEventListener('click', () => this.close());
    this.searchInput.addEventListener('input', () => this.render(this.searchInput.value));
    this.clearBtn.addEventListener('click', () => this.clearAll());
    this.exportJsonBtn?.addEventListener('click', () => this.exportJson());
    this.exportCsvBtn?.addEventListener('click', () => this.exportCsv());

    this.render();
  }

  /** Called once by main.js after the trend <canvas> and LiveGraph exist. */
  attachTrendGraph(graph) {
    this.trendGraph = graph;
    this.trendGraph.setSeries(this.recentDownloadSeries());
  }

  add(result) {
    this.entries.unshift(result);
    if (this.entries.length > MAX_ENTRIES) this.entries.length = MAX_ENTRIES;
    saveEntries(this.entries);
    this.render(this.searchInput.value);
    this.trendGraph?.setSeries(this.recentDownloadSeries());
  }

  remove(timestamp) {
    this.entries = this.entries.filter((e) => e.timestamp !== timestamp);
    saveEntries(this.entries);
    this.render(this.searchInput.value);
    this.trendGraph?.setSeries(this.recentDownloadSeries());
  }

  clearAll() {
    if (this.entries.length === 0) return;
    this.entries = [];
    saveEntries(this.entries);
    this.render();
    this.trendGraph?.reset();
  }

  /** Recent download speeds, oldest first, for the trend sparkline. */
  recentDownloadSeries(count = 20) {
    return this.entries.slice(0, count).reverse().map((e) => e.download);
  }

  exportJson() {
    this._downloadBlob(
      JSON.stringify(this.entries, null, 2),
      'speedbeam-history.json',
      'application/json'
    );
  }

  exportCsv() {
    const header = 'timestamp,date,download_mbps,upload_mbps,ping_ms,jitter_ms,packet_loss_pct,grade';
    const rows = this.entries.map((e) =>
      [
        e.timestamp,
        new Date(e.timestamp).toISOString(),
        e.download.toFixed(2),
        e.upload.toFixed(2),
        e.ping.toFixed(1),
        e.jitter.toFixed(1),
        (e.packetLoss ?? 0).toFixed(1),
        e.grade
      ].join(',')
    );
    this._downloadBlob([header, ...rows].join('\n'), 'speedbeam-history.csv', 'text/csv');
  }

  _downloadBlob(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  open() {
    this.panel.classList.add('is-open');
    this.panel.setAttribute('aria-hidden', 'false');
    this.scrim.hidden = false;
    this.toggleBtn.setAttribute('aria-expanded', 'true');
  }

  close() {
    this.panel.classList.remove('is-open');
    this.panel.setAttribute('aria-hidden', 'true');
    this.scrim.hidden = true;
    this.toggleBtn.setAttribute('aria-expanded', 'false');
  }

  render(filter = '') {
    const q = filter.trim().toLowerCase();
    const filtered = q
      ? this.entries.filter((e) => {
          const haystack =
            `${formatDate(e.timestamp)} ${e.grade} ${e.download.toFixed(1)} ${e.upload.toFixed(1)} ${e.ping.toFixed(0)}`.toLowerCase();
          return haystack.includes(q);
        })
      : this.entries;

    this.list.innerHTML = '';
    this.empty.hidden = this.entries.length > 0;

    if (this.entries.length > 0 && filtered.length === 0) {
      const li = document.createElement('li');
      li.className = 'history-empty';
      li.textContent = 'No results match your search.';
      this.list.appendChild(li);
      return;
    }

    filtered.forEach((entry) => {
      const li = document.createElement('li');
      li.className = 'history-item';
      li.innerHTML = `
        <div class="history-item-main">
          <span class="history-item-speed">↓ ${entry.download.toFixed(1)} · ↑ ${entry.upload.toFixed(1)} Mbps</span>
          <span class="history-item-meta">${formatDate(entry.timestamp)} · Ping ${Math.round(entry.ping)}ms · Grade ${entry.grade}</span>
        </div>
      `;
      const delBtn = document.createElement('button');
      delBtn.className = 'history-item-delete';
      delBtn.type = 'button';
      delBtn.setAttribute('aria-label', 'Delete this test');
      delBtn.innerHTML =
        '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M5 5l14 14M19 5L5 19" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
      delBtn.addEventListener('click', () => this.remove(entry.timestamp));
      li.appendChild(delBtn);
      this.list.appendChild(li);
    });
  }
}
