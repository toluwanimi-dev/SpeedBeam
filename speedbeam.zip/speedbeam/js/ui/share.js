/**
 * Renders the test result as a branded, shareable PNG card using an
 * offscreen canvas — dark/glow themed to match the site — and
 * triggers a browser download. No server round-trip needed.
 */
export function downloadResultCard(result) {
  const W = 1080, H = 1080;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');

  // background
  const bg = ctx.createRadialGradient(W / 2, H * 0.35, 0, W / 2, H * 0.35, W * 0.75);
  bg.addColorStop(0, '#0e1638');
  bg.addColorStop(0.55, '#05070f');
  bg.addColorStop(1, '#020308');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // aurora glows
  const glow1 = ctx.createRadialGradient(W * 0.25, H * 0.18, 0, W * 0.25, H * 0.18, W * 0.4);
  glow1.addColorStop(0, 'rgba(0,212,255,0.25)');
  glow1.addColorStop(1, 'rgba(0,212,255,0)');
  ctx.fillStyle = glow1;
  ctx.fillRect(0, 0, W, H);

  const glow2 = ctx.createRadialGradient(W * 0.8, H * 0.15, 0, W * 0.8, H * 0.15, W * 0.4);
  glow2.addColorStop(0, 'rgba(123,97,255,0.22)');
  glow2.addColorStop(1, 'rgba(123,97,255,0)');
  ctx.fillStyle = glow2;
  ctx.fillRect(0, 0, W, H);

  // brand mark + name
  ctx.beginPath();
  ctx.arc(90, 96, 16, 0, Math.PI * 2);
  const markGrad = ctx.createLinearGradient(74, 80, 106, 112);
  markGrad.addColorStop(0, '#00d4ff');
  markGrad.addColorStop(1, '#7b61ff');
  ctx.fillStyle = markGrad;
  ctx.shadowColor = '#00d4ff';
  ctx.shadowBlur = 24;
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.fillStyle = '#e8f4ff';
  ctx.font = '600 34px "Space Grotesk", sans-serif';
  ctx.textBaseline = 'middle';
  ctx.fillText('SpeedBeam', 124, 98);

  // grade badge
  const gradeColors = {
    'A+': ['#00ffb0', '#00d4ff'], A: ['#4fe0c0', '#00d4ff'], B: ['#00d4ff', '#7b61ff'],
    C: ['#ffcf5c', '#ff9f5c'], D: ['#ff9f5c', '#ff6b6b'], F: ['#ff6b6b', '#c43d3d']
  };
  const [gc1, gc2] = gradeColors[result.grade] ?? gradeColors.B;
  ctx.textAlign = 'right';
  ctx.font = '700 120px "Space Grotesk", sans-serif';
  const gradeGrad = ctx.createLinearGradient(W - 340, 0, W - 60, 0);
  gradeGrad.addColorStop(0, gc1);
  gradeGrad.addColorStop(1, gc2);
  ctx.fillStyle = gradeGrad;
  ctx.fillText(result.grade, W - 70, 130);
  ctx.textAlign = 'left';

  ctx.fillStyle = 'rgba(232,244,255,0.55)';
  ctx.font = '500 22px "Inter", sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText('NETWORK GRADE', W - 70, 200);
  ctx.textAlign = 'left';

  // metrics
  const metrics = [
    ['DOWNLOAD', `${result.download.toFixed(1)}`, 'Mbps'],
    ['UPLOAD', `${result.upload.toFixed(1)}`, 'Mbps'],
    ['PING', `${Math.round(result.ping)}`, 'ms'],
    ['JITTER', `${result.jitter.toFixed(1)}`, 'ms']
  ];

  const cardW = (W - 60 * 3) / 2;
  const cardH = 220;
  const startY = 320;

  metrics.forEach(([label, value, unit], i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 60 + col * (cardW + 60);
    const y = startY + row * (cardH + 30);

    // glass card
    ctx.fillStyle = 'rgba(14,22,56,0.5)';
    roundRect(ctx, x, y, cardW, cardH, 24);
    ctx.fill();
    ctx.strokeStyle = 'rgba(232,244,255,0.14)';
    ctx.lineWidth = 1.5;
    roundRect(ctx, x, y, cardW, cardH, 24);
    ctx.stroke();

    ctx.fillStyle = 'rgba(232,244,255,0.5)';
    ctx.font = '600 22px "Inter", sans-serif';
    ctx.fillText(label, x + 32, y + 46);

    ctx.fillStyle = '#e8f4ff';
    ctx.font = '700 64px "JetBrains Mono", monospace';
    ctx.fillText(value, x + 32, y + 130);

    ctx.fillStyle = 'rgba(232,244,255,0.5)';
    ctx.font = '500 24px "Inter", sans-serif';
    ctx.fillText(unit, x + 32 + ctx.measureText(value).width + 14, y + 130);
  });

  // footer
  ctx.fillStyle = 'rgba(232,244,255,0.4)';
  ctx.font = '500 22px "Inter", sans-serif';
  ctx.fillText(`Tested ${new Date(result.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })} · speedbeam`, 60, H - 60);

  const link = document.createElement('a');
  link.download = `speedbeam-result-${result.timestamp}.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
