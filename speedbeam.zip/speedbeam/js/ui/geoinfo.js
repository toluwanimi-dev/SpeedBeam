/**
 * Best-effort ISP/network detection using ipapi.co's free, CORS-enabled
 * endpoint — no API key needed. This is IP/ASN-based, not the Wi-Fi
 * network name (which isn't detectable or meaningful from a browser
 * anyway). Results are shown only when reasonably confident; when the
 * lookup fails or returns nothing usable, callers get a clear
 * "unavailable" state rather than a guess.
 */
let cached = null;

// Known consumer ISPs/carriers we can confidently label by matching
// against the raw "org" string ipapi.co returns (e.g. "AS29465 MTN
// Nigeria Communication limited"). This is deliberately a name-mapping
// layer, not a guess — if nothing matches, we just show the raw org.
const KNOWN_PROVIDERS = [
  { match: /starlink|spacex/i, name: 'Starlink', type: 'Satellite' },
  { match: /\bmtn\b/i, name: 'MTN', type: 'Mobile' },
  { match: /\bairtel\b/i, name: 'Airtel', type: 'Mobile' },
  { match: /globacom|\bglo\b/i, name: 'Glo (Globacom)', type: 'Mobile' },
  { match: /9mobile|etisalat/i, name: '9mobile', type: 'Mobile' },
  { match: /vodafone/i, name: 'Vodafone', type: 'Mobile' },
  { match: /\bverizon\b/i, name: 'Verizon', type: 'Broadband' },
  { match: /comcast|xfinity/i, name: 'Comcast (Xfinity)', type: 'Broadband' },
  { match: /at&t|\batt\b/i, name: 'AT&T', type: 'Broadband' },
  { match: /t-mobile/i, name: 'T-Mobile', type: 'Mobile' },
  { match: /spectrum|charter/i, name: 'Spectrum', type: 'Broadband' },
  { match: /\bjio\b/i, name: 'Jio', type: 'Mobile' },
  { match: /airtel india/i, name: 'Airtel India', type: 'Mobile' },
  { match: /bt group|british telecom/i, name: 'BT', type: 'Broadband' },
  { match: /orange/i, name: 'Orange', type: 'Mobile' },
  { match: /deutsche telekom|\bt-online\b/i, name: 'Deutsche Telekom', type: 'Broadband' }
];

function inferConnectionType(orgString) {
  if (!orgString) return 'Unknown';
  const known = KNOWN_PROVIDERS.find((p) => p.match.test(orgString));
  if (known) return known.type;
  if (/mobile|wireless|cellular|\blte\b|\b4g\b|\b5g\b/i.test(orgString)) return 'Mobile';
  if (/satellite/i.test(orgString)) return 'Satellite';
  if (/hosting|data center|datacenter|cloud|amazon|google|microsoft|digitalocean/i.test(orgString)) {
    return 'Hosting/VPN (not a home connection)';
  }
  return 'Broadband';
}

function normalizeProviderName(orgString) {
  if (!orgString) return null;
  const known = KNOWN_PROVIDERS.find((p) => p.match.test(orgString));
  if (known) return { name: known.name, confident: true };
  // Strip a leading ASN number ("AS29465 MTN Nigeria...") for a cleaner
  // raw display when we don't have a specific mapping for it.
  const cleaned = orgString.replace(/^AS\d+\s*/i, '').trim();
  return { name: cleaned || orgString, confident: false };
}

export async function detectNetworkInfo() {
  if (cached) return cached;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3000);
  try {
    // Note: even though sequence.js races this against a short timeout
    // so it never delays the test, we still bound the request itself —
    // otherwise a hung connection leaves a fetch running in the
    // background indefinitely after the caller has already moved on.
    const res = await fetch('https://ipapi.co/json/', {
      cache: 'no-store',
      signal: controller.signal
    });
    if (!res.ok) return null; // includes rate-limit (429) and server errors — fail quietly
    let data;
    try {
      data = await res.json();
    } catch {
      return null; // malformed/non-JSON response
    }
    if (data.error) return null;

    const org = data.org || null;
    const asn = data.asn || null;
    const provider = normalizeProviderName(org);

    cached = {
      providerName: provider?.name ?? null,
      confident: provider?.confident ?? false,
      asn,
      rawOrg: org,
      connectionType: inferConnectionType(org),
      city: data.city || null,
      region: data.region || null,
      country: data.country_name || null
    };
    return cached;
  } catch {
    // network error, abort/timeout, or anything else unexpected —
    // detection is best-effort, so fail quietly rather than surface
    // this to the test flow at all
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

/** Short line for the hero area, e.g. "MTN · Lagos, Lagos". */
export function formatNetworkInfo(info) {
  if (!info) return null;
  const place = [info.city, info.region].filter(Boolean).join(', ');
  if (info.providerName && place) return `${info.providerName} · ${place}`;
  if (info.providerName) return info.providerName;
  if (place) return place;
  return null;
}

/** Provider label for the results panel — never invents a name. */
export function providerLabel(info) {
  if (!info || !info.providerName) return 'Network provider unavailable';
  return info.providerName;
}

/** Connection-type label for the results panel. */
export function connectionTypeLabel(info) {
  if (!info) return 'Unknown';
  return info.connectionType || 'Unknown';
}
