/**
 * Optional "monitor mode": re-runs the full test every intervalMs and
 * hands each result to onResult, so the caller can graph stability
 * over time (useful for diagnosing an intermittently flaky connection).
 */
export class MonitorMode {
  constructor({ intervalMs = 5 * 60 * 1000, runTest, onResult, onTick } = {}) {
    this.intervalMs = intervalMs;
    this.runTest = runTest;
    this.onResult = onResult;
    this.onTick = onTick;
    this.timer = null;
    this.active = false;
  }

  start() {
    if (this.active) return;
    this.active = true;
    this._scheduleNext();
  }

  stop() {
    this.active = false;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  _scheduleNext() {
    if (!this.active) return;
    this.timer = setTimeout(async () => {
      if (!this.active) return;
      try {
        const result = await this.runTest();
        this.onResult?.(result);
      } catch {
        // a single failed cycle shouldn't stop monitor mode
      }
      this._scheduleNext();
    }, this.intervalMs);
    this.onTick?.(this.intervalMs);
  }
}
