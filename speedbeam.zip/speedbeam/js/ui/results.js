import { gsap } from 'gsap';

export class ResultsPanel {
  constructor() {
    this.section = document.getElementById('results-section');
    this.heroSection = document.getElementById('hero-section');
    this.els = {
      download: document.getElementById('res-download'),
      upload: document.getElementById('res-upload'),
      ping: document.getElementById('res-ping'),
      jitter: document.getElementById('res-jitter'),
      grade: document.getElementById('res-grade')
    };
    this.cards = Array.from(this.section.querySelectorAll('.glass-card'));
  }

  show(result) {
    this.els.download.textContent = result.download.toFixed(1);
    this.els.upload.textContent = result.upload.toFixed(1);
    this.els.ping.textContent = Math.round(result.ping).toString();
    this.els.jitter.textContent = result.jitter.toFixed(1);
    this.els.grade.textContent = result.grade;

    gsap.to(this.heroSection, {
      opacity: 0,
      y: -16,
      duration: 0.4,
      ease: 'power2.out',
      onComplete: () => {
        this.heroSection.hidden = true;
        this.section.hidden = false;
        gsap.set(this.cards, { opacity: 0, y: 24 });
        gsap.to(this.cards, {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.08,
          ease: 'back.out(1.4)'
        });
      }
    });
  }

  reset() {
    this.section.hidden = true;
    this.heroSection.hidden = false;
    gsap.set(this.heroSection, { opacity: 1, y: 0 });
  }
}
