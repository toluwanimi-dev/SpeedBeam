import { gsap } from 'gsap';
import { initScene } from './scene/index.js';
import { runSpeedTest } from './speedtest/sequence.js';
import { Speedometer } from './ui/speedometer.js';
import { ResultsPanel } from './ui/results.js';
import { buildAssistantMessage, fetchAiAssistantMessage } from './ui/assistant.js';
import { HistoryPanel } from './ui/history.js';
import { SoundEngine } from './audio/sound.js';

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const canvas = document.getElementById('bg-canvas');
const scene = initScene(canvas);

const speedometer = new Speedometer();
const results = new ResultsPanel();
const history = new HistoryPanel();
const sound = new SoundEngine();

const startBtn = document.getElementById('start-btn');
const startLabel = document.getElementById('start-label');
const statusLine = document.getElementById('status-line');
const heroSub = document.getElementById('hero-sub');
const retestBtn = document.getElementById('retest-btn');
const assistantText = document.getElementById('assistant-text');
const liveRegion = document.getElementById('live-region');
const soundToggle = document.getElementById('sound-toggle');
const iconOn = document.getElementById('icon-sound-on');
const iconOff = document.getElementById('icon-sound-off');

const STATUS_TEXT = {
  idle: 'Idle — link stable',
  scan: 'Scanning network path…',
  ping: 'Measuring latency…',
  download: 'Measuring download…',
  upload: 'Measuring upload…',
  resolve: 'Compiling results…'
};

let isTesting = false;

function announce(text) {
  liveRegion.textContent = text;
}

function spawnEnergyWave() {
  if (reducedMotion) return;
  const ring = document.createElement('div');
  ring.className = 'energy-ring';
  document.body.appendChild(ring);
  setTimeout(() => ring.remove(), 1100);
}

function zoomCameraIn() {
  if (reducedMotion) return;
  gsap.to(scene.camera.position, {
    z: 5.6,
    duration: 0.9,
    ease: 'power3.out',
    yoyo: true,
    repeat: 1
  });
}

async function startTest() {
  if (isTesting) return;
  isTesting = true;
  sound.click();
  spawnEnergyWave();
  zoomCameraIn();

  startBtn.setAttribute('disabled', 'true');
  startLabel.textContent = 'Charging…';
  scene.sphere.setState('charging');
  sound.charge();
  speedometer.reset();
  announce('Speed test started.');

  let lastStage = null;

  try {
    const result = await runSpeedTest({
      onStage: (stage) => {
        if (stage !== lastStage) {
          sound.stageTransition();
          lastStage = stage;
        }
        scene.sphere.setState(stage === 'ping' ? 'scan' : stage);
        speedometer.setStage(stage);
        statusLine.textContent = STATUS_TEXT[stage] ?? 'Working…';
        startLabel.textContent =
          stage === 'download' ? 'Downloading…' :
          stage === 'upload' ? 'Uploading…' :
          stage === 'ping' ? 'Pinging…' :
          stage === 'resolve' ? 'Analyzing…' : 'Scanning…';
        announce(STATUS_TEXT[stage] ?? stage);
      },
      onLiveValue: (value, unit) => {
        speedometer.setLive(value, unit);
      },
      onEnergy: (v) => {
        scene.setEnergy(v);
      },
      onComplete: () => {
        scene.sphere.setState('resolve');
        scene.setEnergy(0.15);
      },
      onError: () => {
        scene.sphere.setState('idle');
        scene.setEnergy(0);
      }
    });

    speedometer.showFinal(result);
    sound.complete();
    // Show the instant rule-based verdict first so the UI never feels
    // like it's waiting, then swap in the AI-generated one if/when it
    // arrives (falls back silently to the rule-based text on failure).
    assistantText.textContent = buildAssistantMessage(result);
    fetchAiAssistantMessage(result).then((aiText) => {
      if (aiText) assistantText.textContent = aiText;
    });
    results.show(result);
    history.add(result);
    statusLine.textContent = 'Idle — link stable';
    announce(`Test complete. Download ${result.download.toFixed(1)} megabits per second, grade ${result.grade}.`);
  } catch (err) {
    statusLine.textContent = 'Test interrupted — check your connection';
    heroSub.textContent = 'Something interrupted the measurement. Please try again.';
    announce('Speed test failed. Please try again.');
    scene.sphere.setState('idle');
    scene.setEnergy(0);
  } finally {
    isTesting = false;
    startBtn.removeAttribute('disabled');
    startLabel.textContent = 'Start Test';
  }
}

function resetToHero() {
  results.reset();
  speedometer.reset();
  scene.sphere.setState('idle');
  scene.setEnergy(0);
  statusLine.textContent = 'Idle — link stable';
}

startBtn.addEventListener('click', startTest);
startBtn.addEventListener('pointerenter', () => sound.hover());
retestBtn.addEventListener('click', () => {
  resetToHero();
  startTest();
});

soundToggle.addEventListener('click', () => {
  const nextEnabled = !sound.enabled;
  sound.setEnabled(nextEnabled);
  soundToggle.setAttribute('aria-pressed', String(nextEnabled));
  iconOn.hidden = !nextEnabled;
  iconOff.hidden = nextEnabled;
});

// Keyboard shortcut: space/enter on the crystal button already works
// natively since it's a <button>; no extra wiring needed.
