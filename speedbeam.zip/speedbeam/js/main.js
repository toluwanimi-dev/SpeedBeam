import { gsap } from 'gsap';
import { initScene } from './scene/index.js';
import { runSpeedTest } from './speedtest/sequence.js';
import { pingQuality } from './speedtest/engine.js';
import { Speedometer } from './ui/speedometer.js';
import { ResultsPanel } from './ui/results.js';
import { buildAssistantMessage, fetchAiAssistantMessage } from './ui/assistant.js';
import { HistoryPanel } from './ui/history.js';
import { SoundEngine } from './audio/sound.js';
import { LiveGraph } from './ui/graph.js';
import { downloadResultCard } from './ui/share.js';
import { loadPlanSpeed, savePlanSpeed, comparePlan } from './ui/planCompare.js';
import { detectNetworkInfo, formatNetworkInfo, providerLabel, connectionTypeLabel } from './ui/geoinfo.js';
import { MonitorMode } from './ui/monitor.js';

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const canvas = document.getElementById('bg-canvas');
const scene = initScene(canvas);

const speedometer = new Speedometer();
const results = new ResultsPanel();
const history = new HistoryPanel();
const sound = new SoundEngine();

const startBtn = document.getElementById('start-btn');
const startLabel = document.getElementById('start-label');
const statusLine = document.getElementById('status-line');
const heroSub = document.getElementById('hero-sub');
const retestBtn = document.getElementById('retest-btn');
const shareBtn = document.getElementById('share-btn');
const assistantText = document.getElementById('assistant-text');
const liveRegion = document.getElementById('live-region');
const soundToggle = document.getElementById('sound-toggle');
const iconOn = document.getElementById('icon-sound-on');
const iconOff = document.getElementById('icon-sound-off');
const networkInfoEl = document.getElementById('network-info');
const liveGraphCanvas = document.getElementById('live-graph');
const planCompareText = document.getElementById('plan-compare-text');
const gradeCard = document.getElementById('grade-card');
const packetLossEl = document.getElementById('res-packetloss');
const networkResultEl = document.getElementById('res-network');
const connectionResultEl = document.getElementById('res-connection');
const pingQualityEl = document.getElementById('ping-quality');

const STATUS_TEXT = {
  idle: 'Idle — link stable',
  scan: 'Connecting…',
  detect: 'Detecting network…',
  ping: 'Measuring latency…',
  download: 'Measuring download…',
  upload: 'Measuring upload…',
  resolve: 'Finalizing results…'
};

let latestNetworkInfo = null;

let isTesting = false;
let lastResult = null;

// ---------- Live throughput graph ----------
const liveGraph = new LiveGraph(liveGraphCanvas, { maxPoints: 60 });

// ---------- History trend chart ----------
const trendCanvas = document.getElementById('history-trend-canvas');
if (trendCanvas) {
  const trendGraph = new LiveGraph(trendCanvas, { maxPoints: 20, color: '#7b61ff', fillColor: 'rgba(123,97,255,0.12)' });
  history.attachTrendGraph(trendGraph);
}

// ---------- Network info (ISP/location) ----------
detectNetworkInfo().then((info) => {
  latestNetworkInfo = info;
  const label = formatNetworkInfo(info);
  if (label) {
    networkInfoEl.textContent = label;
    networkInfoEl.hidden = false;
  }
});

// ---------- Settings panel wiring ----------
const settingsToggle = document.getElementById('settings-toggle');
const settingsClose = document.getElementById('settings-close');
const settingsPanel = document.getElementById('settings-panel');
const historyPanel = document.getElementById('history-panel');
const scrim = document.getElementById('scrim');
const planInput = document.getElementById('plan-speed-input');
const multiStreamToggle = document.getElementById('multistream-toggle');
const monitorToggle = document.getElementById('monitor-toggle');
const howItWorksToggle = document.getElementById('how-it-works-toggle');
const howItWorksPanel = document.getElementById('how-it-works-panel');

const savedPlan = loadPlanSpeed();
if (savedPlan) planInput.value = savedPlan;

planInput.addEventListener('change', () => {
  savePlanSpeed(Number(planInput.value) || 0);
});

howItWorksToggle.addEventListener('click', () => {
  howItWorksPanel.hidden = !howItWorksPanel.hidden;
});

function openSettings() {
  historyPanel.classList.remove('is-open');
  settingsPanel.classList.add('is-open');
  settingsPanel.setAttribute('aria-hidden', 'false');
  scrim.hidden = false;
  settingsToggle.setAttribute('aria-expanded', 'true');
}
function closeSettings() {
  settingsPanel.classList.remove('is-open');
  settingsPanel.setAttribute('aria-hidden', 'true');
  scrim.hidden = true;
  settingsToggle.setAttribute('aria-expanded', 'false');
}
settingsToggle.addEventListener('click', openSettings);
settingsClose.addEventListener('click', closeSettings);
scrim.addEventListener('click', () => {
  closeSettings();
});
document.getElementById('history-toggle').addEventListener('click', closeSettings);

// ---------- Monitor mode ----------
const monitorHint = document.getElementById('monitor-hint');
const monitor = new MonitorMode({
  intervalMs: 5 * 60 * 1000,
  runTest: () => runFullTest({ silent: true }),
  onResult: () => {
    monitorHint.textContent = `Monitoring — last check ${new Date().toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}. Next in ~5 minutes.`;
  }
});
monitorToggle.addEventListener('change', () => {
  if (monitorToggle.checked) {
    monitor.start();
    monitorHint.textContent = 'Monitoring active — next automatic test in ~5 minutes.';
  } else {
    monitor.stop();
    monitorHint.textContent = 'Automatically re-tests every 5 minutes and tracks stability in your history trend.';
  }
});

// ---------- Idle easter egg ----------
let idleTimer = null;
function resetIdleTimer() {
  if (idleTimer) clearTimeout(idleTimer);
  if (isTesting) return;
  idleTimer = setTimeout(() => {
    if (!isTesting && !reducedMotion) {
      scene.sphere.burst(0.6);
      statusLine.textContent = 'Idle — link stable · still here?';
      setTimeout(() => {
        if (!isTesting) statusLine.textContent = 'Idle — link stable';
      }, 2500);
    }
  }, 30000);
}
['pointermove', 'keydown', 'click'].forEach((evt) =>
  window.addEventListener(evt, resetIdleTimer, { passive: true })
);
resetIdleTimer();

function announce(text) {
  liveRegion.textContent = text;
}

function spawnEnergyWave() {
  if (reducedMotion) return;
  const ring = document.createElement('div');
  ring.className = 'energy-ring';
  document.body.appendChild(ring);
  setTimeout(() => ring.remove(), 1100);
}

function zoomCameraIn() {
  if (reducedMotion) return;
  gsap.to(scene.camera.position, {
    z: 5.6,
    duration: 0.9,
    ease: 'power3.out',
    yoyo: true,
    repeat: 1
  });
}

async function runFullTest({ silent = false } = {}) {
  if (isTesting) return null;
  isTesting = true;
  if (!silent) {
    sound.click();
    spawnEnergyWave();
    zoomCameraIn();
    startBtn.setAttribute('disabled', 'true');
    startLabel.textContent = 'Charging…';
    speedometer.reset();
    liveGraph.reset();
    liveGraphCanvas.hidden = false;
    announce('Speed test started.');
  }
  scene.sphere.setState('charging');
  if (!silent) sound.charge();

  let lastStage = null;

  try {
    const result = await runSpeedTest(
      {
        onStage: (stage) => {
          if (stage !== lastStage) {
            if (!silent) sound.stageTransition();
            if (lastStage) scene.sphere.burst(1.2); // burst on every stage completion
            lastStage = stage;
          }
          scene.sphere.setState(stage === 'ping' || stage === 'detect' ? 'scan' : stage);
          if (!silent) {
            speedometer.setStage(stage);
            statusLine.textContent = STATUS_TEXT[stage] ?? 'Working…';
            startLabel.textContent =
              stage === 'download' ? 'Downloading…' :
              stage === 'upload' ? 'Uploading…' :
              stage === 'ping' ? 'Pinging…' :
              stage === 'detect' ? 'Detecting…' :
              stage === 'resolve' ? 'Analyzing…' : 'Scanning…';
            announce(STATUS_TEXT[stage] ?? stage);
          }
        },
        onLiveValue: (value, unit) => {
          if (silent) return;
          speedometer.setLive(value, unit);
          if (unit === 'Mbps') liveGraph.push(value);
        },
        onEnergy: (v) => scene.setEnergy(v),
        onComplete: () => {
          scene.sphere.setState('resolve');
          scene.setEnergy(0.15);
          scene.sphere.burst(2);
        },
        onError: () => {
          scene.sphere.setState('idle');
          scene.setEnergy(0);
        }
      },
      {
        streams: multiStreamToggle.checked ? 4 : 1,
        detectNetwork: () => detectNetworkInfo().then((info) => {
          latestNetworkInfo = info;
          return info;
        })
      }
    );

    lastResult = result;
    history.add(result);

    if (!silent) {
      speedometer.showFinal(result);
      sound.complete();
      packetLossEl.textContent = (result.packetLoss ?? 0).toFixed(0);

      const quality = pingQuality(result.ping);
      pingQualityEl.textContent = quality;
      pingQualityEl.setAttribute('data-quality', quality);

      networkResultEl.textContent = providerLabel(latestNetworkInfo);
      connectionResultEl.textContent = connectionTypeLabel(latestNetworkInfo);

      const grade = result.grade;
      gradeCard.setAttribute('data-grade', grade);

      assistantText.textContent = buildAssistantMessage(result);
      fetchAiAssistantMessage(result).then((aiText) => {
        if (aiText) assistantText.textContent = aiText;
      });

      const plan = loadPlanSpeed();
      const compareLine = comparePlan(result.download, plan);
      if (compareLine) {
        planCompareText.textContent = compareLine;
        planCompareText.hidden = false;
      } else {
        planCompareText.hidden = true;
      }

      results.show(result);
      statusLine.textContent = 'Idle — link stable';
      announce(`Test complete. Download ${result.download.toFixed(1)} megabits per second, grade ${result.grade}.`);
    }

    return result;
  } catch (err) {
    if (!silent) {
      statusLine.textContent = 'Test interrupted — check your connection';
      heroSub.textContent = 'Something interrupted the measurement. Please try again.';
      announce('Speed test failed. Please try again.');
    }
    scene.sphere.setState('idle');
    scene.setEnergy(0);
    throw err;
  } finally {
    isTesting = false;
    if (!silent) {
      startBtn.removeAttribute('disabled');
      startLabel.textContent = 'Start Test';
    }
  }
}

function resetToHero() {
  results.reset();
  speedometer.reset();
  liveGraph.reset();
  liveGraphCanvas.hidden = true;
  scene.sphere.setState('idle');
  scene.setEnergy(0);
  statusLine.textContent = 'Idle — link stable';
}

startBtn.addEventListener('click', () => runFullTest());
startBtn.addEventListener('pointerenter', () => sound.hover());
retestBtn.addEventListener('click', () => {
  resetToHero();
  runFullTest();
});
shareBtn.addEventListener('click', () => {
  if (lastResult) downloadResultCard(lastResult);
});

soundToggle.addEventListener('click', () => {
  const nextEnabled = !sound.enabled;
  sound.setEnabled(nextEnabled);
  soundToggle.setAttribute('aria-pressed', String(nextEnabled));
  iconOn.hidden = !nextEnabled;
  iconOff.hidden = nextEnabled;
});

// ---------- PWA service worker ----------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {
      // offline support is a nice-to-have, not required for the app to work
    });
  });
}
