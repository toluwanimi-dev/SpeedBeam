/**
 * SpeedTestEngine — performs real network measurements against
 * configurable endpoints. Defaults to Cloudflare's public speed-test
 * endpoints (the same ones speed.cloudflare.com uses client-side),
 * which accept cross-origin requests without an API key.
 *
 * If those are unreachable in a given deployment (corporate proxy,
 * ad-blocker, offline demo, etc.) swap ENDPOINTS below for any host
 * that serves a large static file (download) and accepts a POST body
 * (upload) with CORS enabled.
 *
 * All methods report progress via callbacks so the UI can animate in
 * real time rather than waiting for a final number.
 */

const ENDPOINTS = {
  pingUrl: 'https://speed.cloudflare.com/__down?bytes=0',
  downloadUrl: (bytes) => `https://speed.cloudflare.com/__down?bytes=${bytes}`,
  uploadUrl: 'https://speed.cloudflare.com/__up'
};

function nowMs() {
  return performance.now();
}

export class SpeedTestEngine {
  constructor(endpoints = ENDPOINTS) {
    this.endpoints = endpoints;
  }

  /** Measures round-trip latency several times. Returns { ping, jitter, samples }. */
  async measurePing({ rounds = 6, onSample } = {}) {
    const samples = [];
    for (let i = 0; i < rounds; i++) {
      const t0 = nowMs();
      try {
        await fetch(`${this.endpoints.pingUrl}&_=${Date.now()}-${i}`, {
          cache: 'no-store',
          mode: 'cors'
        });
      } catch (err) {
        // network hiccup on this round — skip it, keep going
        continue;
      }
      const rtt = nowMs() - t0;
      samples.push(rtt);
      onSample?.(rtt, i, rounds);
      await new Promise((r) => setTimeout(r, 60));
    }
    if (samples.length === 0) {
      throw new Error('Ping measurement failed — all rounds unreachable.');
    }
    const ping = samples.reduce((a, b) => a + b, 0) / samples.length;
    const jitter =
      samples.length > 1
        ? samples.slice(1).reduce((acc, v, i) => acc + Math.abs(v - samples[i]), 0) /
          (samples.length - 1)
        : 0;
    return { ping, jitter, samples };
  }

  /**
   * Downloads a sequence of chunks, sampling instantaneous throughput
   * as bytes arrive so the caller can animate a live speedometer.
   * Returns Mbps.
   */
  async measureDownload({ durationMs = 6000, onProgress } = {}) {
    const start = nowMs();
    let totalBytes = 0;
    const chunkSizes = [2_000_000, 4_000_000, 8_000_000, 8_000_000, 8_000_000, 8_000_000];
    let ci = 0;

    while (nowMs() - start < durationMs) {
      const bytes = chunkSizes[Math.min(ci, chunkSizes.length - 1)];
      ci++;
      const chunkStart = nowMs();
      let response;
      try {
        response = await fetch(`${this.endpoints.downloadUrl(bytes)}&_=${Date.now()}`, {
          cache: 'no-store',
          mode: 'cors'
        });
      } catch (err) {
        break;
      }
      if (!response.body) {
        // Fallback for browsers without streaming body support
        const buf = await response.arrayBuffer();
        totalBytes += buf.byteLength;
      } else {
        const reader = response.body.getReader();
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          totalBytes += value.length;
          const elapsedSec = (nowMs() - start) / 1000;
          const mbps = (totalBytes * 8) / elapsedSec / 1_000_000;
          onProgress?.(mbps, totalBytes, elapsedSec);
          if (nowMs() - start > durationMs) break;
        }
      }
      const chunkElapsedSec = (nowMs() - chunkStart) / 1000;
      const instMbps = (bytes * 8) / chunkElapsedSec / 1_000_000;
      onProgress?.(instMbps, totalBytes, (nowMs() - start) / 1000);
      if (nowMs() - start >= durationMs) break;
    }

    const totalElapsedSec = (nowMs() - start) / 1000;
    if (totalBytes === 0) {
      throw new Error('Download measurement failed — no bytes received.');
    }
    return (totalBytes * 8) / totalElapsedSec / 1_000_000;
  }

  /**
   * Uploads randomly generated payloads for durationMs, sampling
   * throughput as chunks complete. Returns Mbps.
   */
  async measureUpload({ durationMs = 5000, onProgress } = {}) {
    const start = nowMs();
    let totalBytes = 0;
    const chunkBytes = 1_500_000;

    while (nowMs() - start < durationMs) {
      const payload = new Blob([new Uint8Array(chunkBytes).map(() => (Math.random() * 256) | 0)]);
      const chunkStart = nowMs();
      try {
        await fetch(this.endpoints.uploadUrl, {
          method: 'POST',
          body: payload,
          cache: 'no-store',
          mode: 'cors'
        });
      } catch (err) {
        break;
      }
      totalBytes += chunkBytes;
      const chunkElapsedSec = (nowMs() - chunkStart) / 1000;
      const instMbps = (chunkBytes * 8) / chunkElapsedSec / 1_000_000;
      const totalElapsedSec = (nowMs() - start) / 1000;
      onProgress?.(instMbps, totalBytes, totalElapsedSec);
    }

    const totalElapsedSec = (nowMs() - start) / 1000;
    if (totalBytes === 0) {
      throw new Error('Upload measurement failed — no chunks completed.');
    }
    return (totalBytes * 8) / totalElapsedSec / 1_000_000;
  }
}

/** Maps a result set to a letter grade used by the UI + history. */
export function gradeResult({ download, upload, ping, jitter }) {
  let score = 0;
  score += download >= 200 ? 30 : download >= 100 ? 25 : download >= 50 ? 18 : download >= 20 ? 10 : 4;
  score += upload >= 40 ? 25 : upload >= 20 ? 20 : upload >= 10 ? 14 : upload >= 5 ? 8 : 3;
  score += ping <= 15 ? 25 : ping <= 30 ? 20 : ping <= 60 ? 13 : ping <= 100 ? 7 : 2;
  score += jitter <= 3 ? 20 : jitter <= 8 ? 15 : jitter <= 20 ? 9 : 4;

  if (score >= 88) return 'A+';
  if (score >= 78) return 'A';
  if (score >= 65) return 'B';
  if (score >= 50) return 'C';
  if (score >= 32) return 'D';
  return 'F';
}
