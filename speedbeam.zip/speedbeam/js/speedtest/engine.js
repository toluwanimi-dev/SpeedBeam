/**
 * SpeedTestEngine — performs real network measurements against
 * configurable endpoints. Defaults to Cloudflare's public speed-test
 * endpoints (the same ones speed.cloudflare.com uses client-side),
 * which accept cross-origin requests without an API key.
 *
 * If those are unreachable in a given deployment (corporate proxy,
 * ad-blocker, offline demo, etc.) swap ENDPOINTS below for any host
 * that serves a large static file (download) and accepts a POST body
 * (upload) with CORS enabled.
 *
 * All methods report progress via callbacks so the UI can animate in
 * real time rather than waiting for a final number.
 */

const ENDPOINTS = {
  pingUrl: 'https://speed.cloudflare.com/__down?bytes=0',
  downloadUrl: (bytes) => `https://speed.cloudflare.com/__down?bytes=${bytes}`,
  uploadUrl: 'https://speed.cloudflare.com/__up'
};

// Safety timeout for any single network request made during a test —
// stops a stalled connection from hanging the whole measurement.
const REQUEST_TIMEOUT_MS = 15000;

function nowMs() {
  return performance.now();
}

/**
 * Fraction of the interval [aStart, aEnd] that overlaps [bStart, bEnd].
 * Used to proportionally attribute a chunk's bytes to the measurement
 * window when the chunk straddles the warm-up or end boundary — e.g.
 * a chunk that started 100ms before the warm-up ended and finished
 * 200ms after it only counts ~66% of its bytes toward the result.
 */
function overlapFraction(aStart, aEnd, bStart, bEnd) {
  const dur = aEnd - aStart;
  if (dur <= 0) return 0;
  const overlapStart = Math.max(aStart, bStart);
  const overlapEnd = Math.min(aEnd, bEnd);
  return Math.max(0, Math.min(1, (overlapEnd - overlapStart) / dur));
}

/**
 * Fills a Uint8Array with cryptographically random (incompressible)
 * bytes. crypto.getRandomValues caps out at 65,536 bytes per call, so
 * larger buffers are filled in slices. Falls back to Math.random if
 * the crypto API isn't available (very old browsers).
 */
function fillRandomBytes(arr) {
  if (window.crypto?.getRandomValues) {
    const MAX = 65536;
    for (let offset = 0; offset < arr.length; offset += MAX) {
      window.crypto.getRandomValues(arr.subarray(offset, Math.min(offset + MAX, arr.length)));
    }
  } else {
    for (let i = 0; i < arr.length; i++) arr[i] = (Math.random() * 256) | 0;
  }
  return arr;
}

/** Aborts a controller and swallows the resulting AbortError, if any. */
function safeAbort(controller) {
  try {
    controller?.abort();
  } catch {
    // already aborted / not supported — nothing to do
  }
}

export class SpeedTestEngine {
  constructor(endpoints = ENDPOINTS) {
    this.endpoints = endpoints;
    // One reusable incompressible buffer for uploads — generated once,
    // reused for every chunk, instead of allocating + randomizing a
    // fresh multi-megabyte array per request (expensive on mobile).
    this._uploadChunkBytes = 256_000;
    this._uploadBuffer = null;
  }

  _getUploadBuffer() {
    if (!this._uploadBuffer) {
      this._uploadBuffer = fillRandomBytes(new Uint8Array(this._uploadChunkBytes));
    }
    return this._uploadBuffer;
  }

  /**
   * Measures round-trip latency several times. Returns
   * { ping, jitter, samples, packetLoss, packetLossIsEstimate }.
   *
   * Ping uses the median of the samples with the single fastest and
   * slowest round trimmed first (when enough samples exist) so one
   * outlier — in either direction — can't skew the headline number.
   * Jitter is the mean absolute difference between consecutive
   * samples, computed from the full (untrimmed) sample set.
   *
   * packetLoss is an ESTIMATE only: the % of rounds that never got a
   * response at all. Browsers have no access to raw ICMP/UDP packet
   * loss, so this undercounts true loss and should always be labeled
   * as an estimate in the UI (packetLossIsEstimate is always true).
   */
  async measurePing({ rounds = 8, onSample } = {}) {
    const samples = [];
    let failed = 0;
    for (let i = 0; i < rounds; i++) {
      const controller = new AbortController();
      const timeout = setTimeout(() => safeAbort(controller), REQUEST_TIMEOUT_MS);
      const t0 = nowMs();
      try {
        await fetch(`${this.endpoints.pingUrl}&_=${Date.now()}-${i}`, {
          cache: 'no-store',
          mode: 'cors',
          signal: controller.signal
        });
      } catch (err) {
        failed++;
        continue;
      } finally {
        clearTimeout(timeout);
      }
      const rtt = nowMs() - t0;
      samples.push(rtt);
      onSample?.(rtt, i, rounds);
      await new Promise((r) => setTimeout(r, 60));
    }
    if (samples.length === 0) {
      throw new Error('Ping measurement failed — all rounds unreachable.');
    }

    const sorted = [...samples].sort((a, b) => a - b);
    const trimmed = sorted.length >= 6 ? sorted.slice(1, -1) : sorted;
    const mid = Math.floor(trimmed.length / 2);
    const ping =
      trimmed.length % 2 === 0 ? (trimmed[mid - 1] + trimmed[mid]) / 2 : trimmed[mid];

    const jitter =
      samples.length > 1
        ? samples.slice(1).reduce((acc, v, i) => acc + Math.abs(v - samples[i]), 0) /
          (samples.length - 1)
        : 0;
    const packetLoss = (failed / rounds) * 100;
    return { ping, jitter, samples, packetLoss, packetLossIsEstimate: true };
  }

  /**
   * Downloads a sequence of chunks across `streams` parallel
   * connections, sampling throughput as bytes arrive. Byte accounting
   * for the FINAL Mbps figure is windowed precisely:
   *
   *  - bytes that arrive before `warmupMs` has elapsed are excluded
   *    (TCP slow-start warm-up, not real throughput)
   *  - bytes that arrive after `durationMs` are excluded
   *  - a single streamed chunk that straddles either boundary is
   *    counted proportionally by how much of its arrival window falls
   *    inside the measurement window, rather than all-or-nothing
   *
   * Every stream's reader/controller is cancelled as soon as the test
   * window ends, so no extra bytes keep downloading in the background.
   * Returns Mbps.
   */
  async measureDownload({ durationMs = 6000, onProgress, streams = 1, warmupMs = 600 } = {}) {
    const start = nowMs();
    const safeWarmupMs = Math.min(warmupMs, durationMs * 0.3);
    const warmupEnd = start + safeWarmupMs;
    const hardEnd = start + durationMs;
    const chunkSizes = [2_000_000, 4_000_000, 8_000_000, 8_000_000, 8_000_000, 8_000_000];
    const byteCounters = new Array(streams).fill(0); // all bytes, for live UI
    const measuredCounters = new Array(streams).fill(0); // windowed bytes, for final Mbps
    const controllers = [];

    const runStream = async (streamIndex) => {
      let ci = 0;
      while (nowMs() < hardEnd) {
        const bytes = chunkSizes[Math.min(ci, chunkSizes.length - 1)];
        ci++;
        const controller = new AbortController();
        controllers.push(controller);
        const timeout = setTimeout(() => safeAbort(controller), REQUEST_TIMEOUT_MS);
        const requestStart = nowMs();

        let response;
        try {
          response = await fetch(`${this.endpoints.downloadUrl(bytes)}&_=${Date.now()}-${streamIndex}-${ci}`, {
            cache: 'no-store',
            mode: 'cors',
            signal: controller.signal
          });
        } catch (err) {
          clearTimeout(timeout);
          break;
        }

        if (!response.body) {
          // Fallback for browsers without a streamable response body —
          // we only get one timing sample for the whole transfer, so
          // window it against [requestStart, now] rather than two
          // timestamps taken back-to-back after the fact (which would
          // always measure ~0 elapsed time and silently drop the bytes).
          const buf = await response.arrayBuffer();
          const t1 = nowMs();
          byteCounters[streamIndex] += buf.byteLength;
          measuredCounters[streamIndex] += buf.byteLength * overlapFraction(requestStart, t1, warmupEnd, hardEnd);
          clearTimeout(timeout);
        } else {
          const reader = response.body.getReader();
          let chunkStart = nowMs();
          for (;;) {
            let read;
            try {
              read = await reader.read();
            } catch (err) {
              break; // aborted or connection dropped mid-stream
            }
            const { done, value } = read;
            if (done) break;

            const chunkEnd = nowMs();
            byteCounters[streamIndex] += value.length;
            measuredCounters[streamIndex] += value.length * overlapFraction(chunkStart, chunkEnd, warmupEnd, hardEnd);
            chunkStart = chunkEnd;

            const elapsedSec = (nowMs() - start) / 1000;
            const totalBytes = byteCounters.reduce((a, b) => a + b, 0);
            const mbps = (totalBytes * 8) / Math.max(elapsedSec, 0.001) / 1_000_000;
            onProgress?.(mbps, totalBytes, elapsedSec);

            if (nowMs() >= hardEnd) {
              await reader.cancel().catch(() => {});
              safeAbort(controller);
              break;
            }
          }
          clearTimeout(timeout);
        }

        if (nowMs() >= hardEnd) break;
      }
    };

    try {
      await Promise.all(Array.from({ length: streams }, (_, i) => runStream(i)));
    } finally {
      // belt-and-braces: make sure nothing is left in flight once we
      // return, even if a stream exited via an unexpected error path
      controllers.forEach(safeAbort);
    }

    const totalBytes = byteCounters.reduce((a, b) => a + b, 0);
    if (totalBytes === 0) {
      throw new Error('Download measurement failed — no bytes received.');
    }
    const measuredBytes = measuredCounters.reduce((a, b) => a + b, 0);
    if (measuredBytes === 0) {
      // connection was so slow the warm-up window ate the whole test —
      // fall back to the unfiltered total rather than reporting 0
      const totalElapsedSec = (nowMs() - start) / 1000;
      return (totalBytes * 8) / totalElapsedSec / 1_000_000;
    }
    const measuredWindowSec = Math.max((hardEnd - warmupEnd) / 1000, 0.05);
    return (measuredBytes * 8) / measuredWindowSec / 1_000_000;
  }

  /**
   * Uploads a reused, pre-generated incompressible buffer across
   * `streams` parallel connections. Chunk size is kept relatively
   * small (256KB) both for mobile memory efficiency and so the
   * warm-up/end-boundary windowing below stays reasonably precise —
   * the Fetch API doesn't expose upload progress events, so each
   * whole request's duration is windowed against the measurement
   * period rather than true byte-level timing. Returns Mbps.
   */
  async measureUpload({ durationMs = 5000, onProgress, streams = 1, warmupMs = 400 } = {}) {
    const start = nowMs();
    const safeWarmupMs = Math.min(warmupMs, durationMs * 0.3);
    const warmupEnd = start + safeWarmupMs;
    const hardEnd = start + durationMs;
    const chunkBytes = this._uploadChunkBytes;
    const buffer = this._getUploadBuffer();
    const byteCounters = new Array(streams).fill(0);
    const measuredCounters = new Array(streams).fill(0);
    const controllers = [];

    const runStream = async (streamIndex) => {
      while (nowMs() < hardEnd) {
        const controller = new AbortController();
        controllers.push(controller);
        const timeout = setTimeout(() => safeAbort(controller), REQUEST_TIMEOUT_MS);
        const reqStart = nowMs();
        try {
          // Same underlying bytes reused every time — regenerating
          // fresh random data per chunk isn't necessary for measuring
          // throughput and was needlessly expensive on mobile CPUs.
          await fetch(this.endpoints.uploadUrl, {
            method: 'POST',
            body: buffer,
            cache: 'no-store',
            mode: 'cors',
            signal: controller.signal
          });
        } catch (err) {
          clearTimeout(timeout);
          break;
        }
        clearTimeout(timeout);
        const reqEnd = nowMs();

        byteCounters[streamIndex] += chunkBytes;
        measuredCounters[streamIndex] += chunkBytes * overlapFraction(reqStart, reqEnd, warmupEnd, hardEnd);

        const totalElapsedSec = (nowMs() - start) / 1000;
        const totalBytes = byteCounters.reduce((a, b) => a + b, 0);
        const instMbps = (totalBytes * 8) / Math.max(totalElapsedSec, 0.001) / 1_000_000;
        onProgress?.(instMbps, totalBytes, totalElapsedSec);
      }
    };

    try {
      await Promise.all(Array.from({ length: streams }, (_, i) => runStream(i)));
    } finally {
      controllers.forEach(safeAbort);
    }

    const totalBytes = byteCounters.reduce((a, b) => a + b, 0);
    if (totalBytes === 0) {
      throw new Error('Upload measurement failed — no chunks completed.');
    }
    const measuredBytes = measuredCounters.reduce((a, b) => a + b, 0);
    if (measuredBytes === 0) {
      const totalElapsedSec = (nowMs() - start) / 1000;
      return (totalBytes * 8) / totalElapsedSec / 1_000_000;
    }
    const measuredWindowSec = Math.max((hardEnd - warmupEnd) / 1000, 0.05);
    return (measuredBytes * 8) / measuredWindowSec / 1_000_000;
  }
}

/** Maps a result set to a letter grade used by the UI + history. */
export function gradeResult({ download, upload, ping, jitter, packetLoss = 0 }) {
  let score = 0;
  score += download >= 200 ? 30 : download >= 100 ? 25 : download >= 50 ? 18 : download >= 20 ? 10 : 4;
  score += upload >= 40 ? 25 : upload >= 20 ? 20 : upload >= 10 ? 14 : upload >= 5 ? 8 : 3;
  score += ping <= 15 ? 25 : ping <= 30 ? 20 : ping <= 60 ? 13 : ping <= 100 ? 7 : 2;
  score += jitter <= 3 ? 20 : jitter <= 8 ? 15 : jitter <= 20 ? 9 : 4;
  score -= packetLoss >= 5 ? 15 : packetLoss >= 1 ? 6 : 0;

  if (score >= 88) return 'A+';
  if (score >= 78) return 'A';
  if (score >= 65) return 'B';
  if (score >= 50) return 'C';
  if (score >= 32) return 'D';
  return 'F';
}

/** Maps a ping value in ms to a plain-language quality label. */
export function pingQuality(ms) {
  if (ms < 20) return 'Excellent';
  if (ms < 50) return 'Very Good';
  if (ms < 80) return 'Good';
  if (ms < 150) return 'Fair';
  return 'High';
}

/** Maps a grade letter to a CSS color pair used for dynamic grade styling. */
export function gradeColor(grade) {
  const map = {
    'A+': { a: '#00ffb0', b: '#00d4ff' },
    A: { a: '#4fe0c0', b: '#00d4ff' },
    B: { a: '#00d4ff', b: '#7b61ff' },
    C: { a: '#ffcf5c', b: '#ff9f5c' },
    D: { a: '#ff9f5c', b: '#ff6b6b' },
    F: { a: '#ff6b6b', b: '#c43d3d' }
  };
  return map[grade] ?? map.B;
}
