import { SpeedTestEngine, gradeResult } from './engine.js';

/**
 * Drives the cinematic test sequence — Connecting → Detecting Network
 * → Measuring Latency → Download → Upload → Finalizing — using real
 * measurements from SpeedTestEngine. Calls `hooks` at each transition
 * so the dashboard gauge, 3D scene, and sound layer react in sync.
 *
 * options.streams: number of parallel connections for download/upload
 * (1 = single-stream/realistic, 4+ = multi-stream/ISP-advertised style).
 * options.detectNetwork: optional async fn (e.g. an ISP lookup) run
 * during the "detect" stage. Race'd against a short timeout so a slow
 * or failed lookup never meaningfully delays the test.
 *
 * hooks:
 *   onStage(stageName)
 *   onLiveValue(mbpsOrMs, unit)   // called continuously during a stage
 *   onEnergy(0..1)                // background/sphere intensity
 *   onComplete(results)
 *   onError(error)
 */
export async function runSpeedTest(hooks = {}, options = {}) {
  const engine = new SpeedTestEngine();
  const { streams = 1, detectNetwork = null } = options;
  const {
    onStage = () => {},
    onLiveValue = () => {},
    onEnergy = () => {},
    onComplete = () => {},
    onError = () => {}
  } = hooks;

  try {
    // ---- Stage: Connecting / Preparing ----
    onStage('scan');
    onEnergy(0.25);
    await new Promise((r) => setTimeout(r, 700));

    // ---- Stage: Detecting Network (never blocks more than ~1.2s) ----
    onStage('detect');
    onEnergy(0.3);
    if (detectNetwork) {
      await Promise.race([
        detectNetwork().catch(() => null),
        new Promise((r) => setTimeout(r, 1200))
      ]);
    } else {
      await new Promise((r) => setTimeout(r, 350));
    }

    // ---- Stage: Measuring Latency ----
    onStage('ping');
    onEnergy(0.4);
    const { ping, jitter, packetLoss, packetLossIsEstimate } = await engine.measurePing({
      rounds: 8,
      onSample: (rtt) => onLiveValue(rtt, 'ms')
    });

    // ---- Stage: Measuring Download Speed ----
    onStage('download');
    onEnergy(0.85);
    const download = await engine.measureDownload({
      durationMs: 6000,
      streams,
      onProgress: (mbps) => onLiveValue(mbps, 'Mbps')
    });

    // ---- Stage: Measuring Upload Speed ----
    onStage('upload');
    onEnergy(0.7);
    const upload = await engine.measureUpload({
      durationMs: 5000,
      streams,
      onProgress: (mbps) => onLiveValue(mbps, 'Mbps')
    });

    // ---- Stage: Finalizing Results ----
    onStage('resolve');
    onEnergy(0.2);
    await new Promise((r) => setTimeout(r, 700));

    const grade = gradeResult({ download, upload, ping, jitter, packetLoss });
    const result = {
      download,
      upload,
      ping,
      jitter,
      packetLoss,
      packetLossIsEstimate,
      grade,
      streams,
      timestamp: Date.now()
    };

    onComplete(result);
    return result;
  } catch (err) {
    onError(err);
    throw err;
  }
}
