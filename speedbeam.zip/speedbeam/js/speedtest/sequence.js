import { SpeedTestEngine, gradeResult } from './engine.js';

/**
 * Drives the 5-stage cinematic sequence described in the brief —
 * Scanning → Ping → Download → Upload → Analysis — using real
 * measurements from SpeedTestEngine. Calls `hooks` at each transition
 * so the 3D scene, HUD speedometer, and sound layer can react in sync.
 *
 * hooks:
 *   onStage(stageName)
 *   onLiveValue(mbpsOrMs, unit)   // called continuously during a stage
 *   onEnergy(0..1)                // background/sphere intensity
 *   onComplete(results)
 *   onError(error)
 */
export async function runSpeedTest(hooks = {}) {
  const engine = new SpeedTestEngine();
  const {
    onStage = () => {},
    onLiveValue = () => {},
    onEnergy = () => {},
    onComplete = () => {},
    onError = () => {}
  } = hooks;

  try {
    // ---- Stage 1: Scanning ----
    onStage('scan');
    onEnergy(0.25);
    await new Promise((r) => setTimeout(r, 900));

    // ---- Stage 2: Ping ----
    onStage('ping');
    onEnergy(0.4);
    const { ping, jitter } = await engine.measurePing({
      rounds: 6,
      onSample: (rtt) => onLiveValue(rtt, 'ms')
    });

    // ---- Stage 3: Download ----
    onStage('download');
    onEnergy(0.85);
    const download = await engine.measureDownload({
      durationMs: 6000,
      onProgress: (mbps) => onLiveValue(mbps, 'Mbps')
    });

    // ---- Stage 4: Upload ----
    onStage('upload');
    onEnergy(0.7);
    const upload = await engine.measureUpload({
      durationMs: 5000,
      onProgress: (mbps) => onLiveValue(mbps, 'Mbps')
    });

    // ---- Stage 5: Analysis ----
    onStage('resolve');
    onEnergy(0.2);
    await new Promise((r) => setTimeout(r, 700));

    const grade = gradeResult({ download, upload, ping, jitter });
    const result = {
      download,
      upload,
      ping,
      jitter,
      grade,
      timestamp: Date.now()
    };

    onComplete(result);
    return result;
  } catch (err) {
    onError(err);
    throw err;
  }
}
