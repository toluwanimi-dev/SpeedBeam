import * as THREE from 'three';

/**
 * Builds the deep-space backdrop: starfield, drifting nebula particles,
 * a glowing perspective grid floor, and a handful of floating "network
 * nodes" connected by thin energy lines. Returns an update(dt, elapsed)
 * function the render loop calls each frame.
 */
export function createBackground(scene, { reducedMotion = false } = {}) {
  const group = new THREE.Group();
  scene.add(group);

  // ---------- Starfield ----------
  const starCount = reducedMotion ? 900 : 1800;
  const starGeo = new THREE.BufferGeometry();
  const starPos = new Float32Array(starCount * 3);
  const starPhase = new Float32Array(starCount);
  for (let i = 0; i < starCount; i++) {
    const r = 40 + Math.random() * 60;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(Math.random() * 2 - 1);
    starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    starPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.6;
    starPos[i * 3 + 2] = r * Math.cos(phi) - 20;
    starPhase[i] = Math.random() * Math.PI * 2;
  }
  starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
  const starMat = new THREE.PointsMaterial({
    color: 0xbfe9ff,
    size: 0.16,
    transparent: true,
    opacity: 0.75,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  });
  const stars = new THREE.Points(starGeo, starMat);
  group.add(stars);

  // ---------- Nebula dust (soft colored points, slow drift) ----------
  const dustCount = reducedMotion ? 200 : 420;
  const dustGeo = new THREE.BufferGeometry();
  const dustPos = new Float32Array(dustCount * 3);
  const dustColor = new Float32Array(dustCount * 3);
  const colorA = new THREE.Color(0x00d4ff);
  const colorB = new THREE.Color(0x7b61ff);
  for (let i = 0; i < dustCount; i++) {
    dustPos[i * 3] = (Math.random() - 0.5) * 34;
    dustPos[i * 3 + 1] = (Math.random() - 0.5) * 18;
    dustPos[i * 3 + 2] = (Math.random() - 0.5) * 24 - 8;
    const c = colorA.clone().lerp(colorB, Math.random());
    dustColor[i * 3] = c.r;
    dustColor[i * 3 + 1] = c.g;
    dustColor[i * 3 + 2] = c.b;
  }
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
  dustGeo.setAttribute('color', new THREE.BufferAttribute(dustColor, 3));
  const dustMat = new THREE.PointsMaterial({
    size: 0.22,
    transparent: true,
    opacity: 0.5,
    vertexColors: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  });
  const dust = new THREE.Points(dustGeo, dustMat);
  group.add(dust);

  // ---------- Glowing grid floor ----------
  const grid = new THREE.GridHelper(60, 40, 0x1c4a72, 0x0e2340);
  grid.position.y = -7.5;
  grid.material.transparent = true;
  grid.material.opacity = 0.35;
  group.add(grid);

  // Soft glow plane under the grid to fake volumetric light pooling
  const floorGlow = new THREE.Mesh(
    new THREE.PlaneGeometry(40, 40),
    new THREE.MeshBasicMaterial({
      color: 0x0a2a4a,
      transparent: true,
      opacity: 0.25,
      blending: THREE.AdditiveBlending
    })
  );
  floorGlow.rotation.x = -Math.PI / 2;
  floorGlow.position.y = -7.48;
  group.add(floorGlow);

  // ---------- Floating network nodes + connecting lines ----------
  const nodeCount = 10;
  const nodes = [];
  const nodeGeo = new THREE.SphereGeometry(0.05, 8, 8);
  const nodeMat = new THREE.MeshBasicMaterial({ color: 0x8fe9ff });
  for (let i = 0; i < nodeCount; i++) {
    const mesh = new THREE.Mesh(nodeGeo, nodeMat);
    mesh.position.set(
      (Math.random() - 0.5) * 16,
      (Math.random() - 0.5) * 8 + 1,
      (Math.random() - 0.5) * 10 - 4
    );
    mesh.userData.basePos = mesh.position.clone();
    mesh.userData.phase = Math.random() * Math.PI * 2;
    group.add(mesh);
    nodes.push(mesh);
  }

  const lineMat = new THREE.LineBasicMaterial({
    color: 0x3a6ea8,
    transparent: true,
    opacity: 0.28
  });
  const lineGroup = new THREE.Group();
  group.add(lineGroup);
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      if (nodes[i].position.distanceTo(nodes[j].position) < 7 && Math.random() < 0.35) {
        const geo = new THREE.BufferGeometry().setFromPoints([
          nodes[i].position,
          nodes[j].position
        ]);
        lineGroup.add(new THREE.Line(geo, lineMat));
      }
    }
  }

  let intensity = 0; // driven externally during download/upload surges

  function setIntensity(v) {
    intensity = v;
  }

  function update(dt, elapsed) {
    if (!reducedMotion) {
      group.rotation.y = elapsed * 0.01;
      stars.rotation.y = elapsed * 0.004;
      dust.rotation.y = -elapsed * 0.006;

      nodes.forEach((n) => {
        const p = n.userData.basePos;
        const ph = n.userData.phase;
        n.position.y = p.y + Math.sin(elapsed * 0.6 + ph) * 0.35;
        n.position.x = p.x + Math.cos(elapsed * 0.4 + ph) * 0.2;
      });
    }

    const targetOpacity = 0.35 + intensity * 0.45;
    grid.material.opacity += (targetOpacity - grid.material.opacity) * 0.05;
    dustMat.size = 0.22 + intensity * 0.18;
  }

  return { update, setIntensity, group };
}
