import * as THREE from 'three';
import { createBackground } from './background.js';
import { HeroSphere } from './sphere.js';

export function initScene(canvas) {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isSmall = window.innerWidth < 640;

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x05070f, 0.028);

  const camera = new THREE.PerspectiveCamera(
    50,
    window.innerWidth / window.innerHeight,
    0.1,
    120
  );
  camera.position.set(0, 0.4, 7.2);

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: true,
    powerPreference: 'high-performance'
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, isSmall ? 1.6 : 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  const bg = createBackground(scene, { reducedMotion });
  const sphere = new HeroSphere(scene, { reducedMotion });
  sphere.group.position.set(0, 0.4, 0);

  // ---- Mouse / touch parallax ----
  const pointer = { x: 0, y: 0, targetX: 0, targetY: 0 };
  function onPointerMove(e) {
    const x = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const y = 'touches' in e ? e.touches[0].clientY : e.clientY;
    pointer.targetX = (x / window.innerWidth - 0.5) * 2;
    pointer.targetY = (y / window.innerHeight - 0.5) * 2;
  }
  window.addEventListener('pointermove', onPointerMove, { passive: true });

  // ---- Resize ----
  function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }
  window.addEventListener('resize', onResize);

  // ---- Pause rendering when tab hidden (perf) ----
  let running = true;
  document.addEventListener('visibilitychange', () => {
    running = document.visibilityState === 'visible';
    if (running) {
      lastTime = performance.now();
      requestAnimationFrame(loop);
    }
  });

  let lastTime = performance.now();
  const clock = new THREE.Clock();

  function loop(now) {
    if (!running) return;
    requestAnimationFrame(loop);
    const dt = Math.min(clock.getDelta(), 0.05);
    const elapsed = clock.getElapsedTime();

    if (!reducedMotion) {
      pointer.x += (pointer.targetX - pointer.x) * 0.04;
      pointer.y += (pointer.targetY - pointer.y) * 0.04;

      // Slow automatic camera drift + subtle parallax from pointer
      const autoX = Math.sin(elapsed * 0.05) * 0.6;
      const autoY = Math.cos(elapsed * 0.04) * 0.25;
      camera.position.x += (autoX + pointer.x * 0.5 - camera.position.x) * 0.03;
      camera.position.y += (0.4 + autoY - pointer.y * 0.3 - camera.position.y) * 0.03;
      camera.lookAt(0, 0.4, 0);
    }

    bg.update(dt, elapsed);
    sphere.update(dt, elapsed);

    renderer.render(scene, camera);
  }

  requestAnimationFrame(loop);

  return {
    scene,
    camera,
    renderer,
    sphere,
    background: bg,
    setEnergy(v) {
      bg.setIntensity(v);
    },
    dispose() {
      running = false;
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
    }
  };
}
