import * as THREE from 'three';

/**
 * The holographic sphere at the heart of SpeedBeam. Built from three
 * layers — an inner glow shell, a wireframe icosahedron, and two
 * independently-rotating particle rings — so it can visibly "charge",
 * spin faster during download, and stream energy outward during upload.
 *
 * States: 'idle' | 'charging' | 'scan' | 'download' | 'upload' | 'resolve'
 */
export class HeroSphere {
  constructor(scene, { reducedMotion = false } = {}) {
    this.reducedMotion = reducedMotion;
    this.group = new THREE.Group();
    scene.add(this.group);

    this.state = 'idle';
    this.spin = 0.15;
    this.targetSpin = 0.15;
    this.energyFlow = new THREE.Group(); // outward particles for upload
    this.group.add(this.energyFlow);

    this._buildCore();
    this._buildWireframe();
    this._buildRings();
    this._buildOrbitParticles();
  }

  _buildCore() {
    const geo = new THREE.IcosahedronGeometry(1.35, 2);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x0d3a5a,
      transparent: true,
      opacity: 0.22,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide
    });
    this.core = new THREE.Mesh(geo, mat);
    this.group.add(this.core);
  }

  _buildWireframe() {
    const geo = new THREE.IcosahedronGeometry(1.5, 3);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x4fd8ff,
      wireframe: true,
      transparent: true,
      opacity: 0.55
    });
    this.wire = new THREE.Mesh(geo, mat);
    this.group.add(this.wire);

    // A slightly larger, slower purple wireframe for depth
    const geo2 = new THREE.IcosahedronGeometry(1.72, 1);
    const mat2 = new THREE.MeshBasicMaterial({
      color: 0x9b7dff,
      wireframe: true,
      transparent: true,
      opacity: 0.22
    });
    this.wireOuter = new THREE.Mesh(geo2, mat2);
    this.group.add(this.wireOuter);
  }

  _buildRings() {
    this.rings = [];
    const ringDefs = [
      { radius: 2.15, tube: 0.008, color: 0x00d4ff, tiltX: Math.PI / 2.4, speed: 0.35 },
      { radius: 2.45, tube: 0.006, color: 0x7b61ff, tiltX: -Math.PI / 3.1, speed: -0.22 },
      { radius: 2.75, tube: 0.005, color: 0x8fe9ff, tiltX: Math.PI / 6, speed: 0.14 }
    ];
    ringDefs.forEach((def) => {
      const geo = new THREE.TorusGeometry(def.radius, def.tube, 8, 128);
      const mat = new THREE.MeshBasicMaterial({
        color: def.color,
        transparent: true,
        opacity: 0.5,
        blending: THREE.AdditiveBlending
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.rotation.x = def.tiltX;
      mesh.userData.speed = def.speed;
      this.group.add(mesh);
      this.rings.push(mesh);
    });
  }

  _buildOrbitParticles() {
    const count = this.reducedMotion ? 60 : 140;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    const data = [];
    for (let i = 0; i < count; i++) {
      const radius = 1.9 + Math.random() * 1.1;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      data.push({ radius, theta, phi, speed: 0.15 + Math.random() * 0.35 });
      pos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = radius * Math.cos(phi);
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xbfe9ff,
      size: 0.045,
      transparent: true,
      opacity: 0.85,
      depthWrite: false,
      blending: THREE.AdditiveBlending
    });
    this.orbitPoints = new THREE.Points(geo, mat);
    this.orbitData = data;
    this.group.add(this.orbitPoints);
  }

  setState(state) {
    this.state = state;
    const targets = {
      idle: 0.15,
      charging: 0.5,
      scan: 0.8,
      download: 2.4,
      upload: 1.6,
      resolve: 0.3
    };
    this.targetSpin = targets[state] ?? 0.15;
  }

  /** Gives every orbit particle an outward kick — used on stage completion. */
  burst(strength = 1.6) {
    if (this.reducedMotion) return;
    this.orbitData.forEach((p) => {
      p.radius += strength * (0.5 + Math.random() * 0.6);
    });
  }

  update(dt, elapsed) {
    this.spin += (this.targetSpin - this.spin) * Math.min(1, dt * 1.5);

    if (!this.reducedMotion) {
      this.wire.rotation.y += dt * this.spin * 0.4;
      this.wire.rotation.x += dt * this.spin * 0.15;
      this.wireOuter.rotation.y -= dt * this.spin * 0.22;
      this.core.rotation.y += dt * this.spin * 0.1;

      this.rings.forEach((r) => {
        r.rotation.z += dt * r.userData.speed * (0.4 + this.spin * 0.5);
      });

      // Breathing scale when idle, surge scale when downloading
      const breathe = this.state === 'idle'
        ? 1 + Math.sin(elapsed * 0.9) * 0.03
        : 1 + Math.min(this.spin / 3, 0.18);
      this.group.scale.setScalar(breathe);

      // Orbit particles: swirl faster with spin, stream outward during upload
      const positions = this.orbitPoints.geometry.attributes.position.array;
      const uploadPush = this.state === 'upload' ? dt * 1.4 : 0;
      this.orbitData.forEach((p, i) => {
        p.theta += dt * p.speed * (0.5 + this.spin * 0.4);
        p.radius += uploadPush * 0.6;
        if (p.radius > 4.2) p.radius = 1.9;
        positions[i * 3] = p.radius * Math.sin(p.phi) * Math.cos(p.theta);
        positions[i * 3 + 1] = p.radius * Math.sin(p.phi) * Math.sin(p.theta);
        positions[i * 3 + 2] = p.radius * Math.cos(p.phi);
      });
      this.orbitPoints.geometry.attributes.position.needsUpdate = true;
    }

    // Color/opacity shifts per stage for a "charging" read
    const wireOpacity = {
      idle: 0.5, charging: 0.7, scan: 0.75, download: 0.95, upload: 0.85, resolve: 0.55
    }[this.state] ?? 0.5;
    this.wire.material.opacity += (wireOpacity - this.wire.material.opacity) * 0.06;
  }
}
